import pandas as pd
from rdkit import Chem
from rdkit.ML.Descriptors import MoleculeDescriptors
from rdkit.Chem import rdMolDescriptors
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.metrics import mean_squared_error, r2_score
import xgboost as xgb

# Load the dataset
file_path = 'aqSol.csv'
data = pd.read_csv(file_path)

# Extract SMILES and solubility (log S) values
smiles_list = data['smiles'].tolist()
solubility = data['log S'].tolist()

# Initialize the descriptor calculator with all available descriptors
descriptor_names = rdMolDescriptors.Properties.GetAvailableProperties()
featurizer = MoleculeDescriptors.MolecularDescriptorCalculator(descriptor_names)

# Calculate descriptors for each molecule
descriptors = [featurizer.CalcDescriptors(Chem.MolFromSmiles(smiles)) for smiles in smiles_list]

# Convert descriptors to a DataFrame
descriptors_df = pd.DataFrame(descriptors, columns=descriptor_names)

# Prepare data for modeling
X = descriptors_df
y = solubility

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define the parameter grid for XGBoost
param_grid = {
    'n_estimators': [100, 200, 300, 500],
    'max_depth': [3, 5, 7, 10],
    'learning_rate': [0.01, 0.05, 0.1, 0.2],
    'subsample': [0.6, 0.8, 1.0],
    'colsample_bytree': [0.6, 0.8, 1.0],
    'gamma': [0, 0.1, 0.2, 0.5]
}

# Initialize the XGBoost Regressor
xgboost = xgb.XGBRegressor(random_state=42)

# Perform RandomizedSearchCV for hyperparameter tuning
xgb_random = RandomizedSearchCV(estimator=xgboost, param_distributions=param_grid, n_iter=100, 
                                cv=3, verbose=2, random_state=42, n_jobs=-1)

# Fit the model
xgb_random.fit(X_train, y_train)

# Get the best parameters
best_params = xgb_random.best_params_
print(f"Best parameters: {best_params}")

# Train the model with the best parameters
best_xgb = xgb_random.best_estimator_
y_pred_best = best_xgb.predict(X_test)

# Evaluate the tuned model
mse_best = mean_squared_error(y_test, y_pred_best)
r2_best = r2_score(y_test, y_pred_best)

print(f"Tuned XGBoost Mean Squared Error: {mse_best}")
print(f"Tuned XGBoost R2 Score: {r2_best}")
