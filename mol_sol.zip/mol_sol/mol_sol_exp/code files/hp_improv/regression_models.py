import pandas as pd
import numpy as np  
from rdkit import Chem
from rdkit.ML.Descriptors import MoleculeDescriptors
from rdkit.Chem import rdMolDescriptors
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.ensemble import GradientBoostingRegressor, AdaBoostRegressor
from xgboost import XGBRegressor  # if installed

# Load the dataset
file_path = 'aqSol.csv'
data = pd.read_csv(file_path)

# Extract SMILES and solubility (log S) values
smiles_list = data['smiles'].tolist()
solubility = data['log S'].tolist()

# Initialize the descriptor calculator with all available descriptors
descriptor_names = rdMolDescriptors.Properties.GetAvailableProperties()
featurizer = MoleculeDescriptors.MolecularDescriptorCalculator(descriptor_names)

# Calculate descriptors for each molecule
descriptors = [featurizer.CalcDescriptors(Chem.MolFromSmiles(smiles)) for smiles in smiles_list]

# Convert descriptors to a DataFrame
descriptors_df = pd.DataFrame(descriptors, columns=descriptor_names)

# Remove highly correlated features
corr_matrix = descriptors_df.corr().abs()
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))

# Drop features with a correlation higher than 0.95
to_drop = [column for column in upper.columns if any(upper[column] > 0.95)]
descriptors_df_reduced = descriptors_df.drop(to_drop, axis=1)

# Prepare data for modeling
X = descriptors_df_reduced
y = solubility

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define a list of models to evaluate
models = {
    "Linear Regression": LinearRegression(),
    "Support Vector Regressor": SVR(),
    "Gradient Boosting Regressor": GradientBoostingRegressor(),
    "AdaBoost Regressor": AdaBoostRegressor(),
    "XGBoost Regressor": XGBRegressor(random_state=42)  # If you have XGBoost installed
}

# Evaluate each model
results = {}

for model_name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    
    results[model_name] = {"MSE": mse, "R2": r2}

# Print out the results for each model
for model_name, metrics in results.items():
    print(f"{model_name}: MSE = {metrics['MSE']:.4f}, R2 = {metrics['R2']:.4f}")
