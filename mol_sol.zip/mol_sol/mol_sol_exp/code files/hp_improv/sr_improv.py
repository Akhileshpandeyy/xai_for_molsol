"""
import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.ML.Descriptors import MoleculeDescriptors
from rdkit.Chem import rdMolDescriptors
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, StackingRegressor
from xgboost import XGBRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV

# Load the dataset
file_path = 'aqSol.csv'
data = pd.read_csv(file_path)

# Extract SMILES and solubility (log S) values
smiles_list = data['smiles'].tolist()
solubility = data['log S'].tolist()

# Initialize the descriptor calculator with all available descriptors
descriptor_names = rdMolDescriptors.Properties.GetAvailableProperties()
featurizer = MoleculeDescriptors.MolecularDescriptorCalculator(descriptor_names)

# Calculate descriptors for each molecule
descriptors = [featurizer.CalcDescriptors(Chem.MolFromSmiles(smiles)) for smiles in smiles_list]

# Convert descriptors to a DataFrame
descriptors_df = pd.DataFrame(descriptors, columns=descriptor_names)

# Remove highly correlated features
corr_matrix = descriptors_df.corr().abs()
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))

# Drop features with a correlation higher than 0.95
to_drop = [column for column in upper.columns if any(upper[column] > 0.95)]
descriptors_df_reduced = descriptors_df.drop(to_drop, axis=1)

# Prepare data for modeling
X = descriptors_df_reduced
y = solubility

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define hyperparameter grids
param_grid_rf = {
    'n_estimators': [100, 200, 300],
    'max_depth': [None, 10, 20],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2]
}

param_grid_gb = {
    'n_estimators': [100, 200, 300],
    'learning_rate': [0.01, 0.1],
    'max_depth': [3, 5, 7]
}

param_grid_xgb = {
    'n_estimators': [100, 200, 300],
    'learning_rate': [0.01, 0.1],
    'max_depth': [3, 5, 7],
    'subsample': [0.6, 0.8, 1.0],
    'gamma': [0, 0.1, 0.5]
}

# Perform GridSearchCV for RandomForestRegressor
rf = RandomForestRegressor(random_state=42)
grid_rf = GridSearchCV(rf, param_grid_rf, cv=3, n_jobs=-1, verbose=2)
grid_rf.fit(X_train, y_train)
best_rf = grid_rf.best_estimator_
print(f"Best RandomForest Parameters: {grid_rf.best_params_}")

# Perform GridSearchCV for GradientBoostingRegressor
gb = GradientBoostingRegressor(random_state=42)
grid_gb = GridSearchCV(gb, param_grid_gb, cv=3, n_jobs=-1, verbose=2)
grid_gb.fit(X_train, y_train)
best_gb = grid_gb.best_estimator_
print(f"Best GradientBoosting Parameters: {grid_gb.best_params_}")

# Perform GridSearchCV for XGBRegressor
xgb = XGBRegressor(random_state=42)
grid_xgb = GridSearchCV(xgb, param_grid_xgb, cv=3, n_jobs=-1, verbose=2)
grid_xgb.fit(X_train, y_train)
best_xgb = grid_xgb.best_estimator_
print(f"Best XGBoost Parameters: {grid_xgb.best_params_}")

# Stacking Regressor with the tuned models
estimators = [
    ('rf', best_rf),
    ('gb', best_gb),
    ('xgb', best_xgb)
]

stacking_model = StackingRegressor(estimators=estimators, final_estimator=Ridge())

# Train the Stacking Regressor
stacking_model.fit(X_train, y_train)

# Make predictions
y_pred_stacking = stacking_model.predict(X_test)

# Evaluate the Stacking Regressor
mse_stacking = mean_squared_error(y_test, y_pred_stacking)
r2_stacking = r2_score(y_test, y_pred_stacking)

print(f'Stacking Regressor Mean Squared Error: {mse_stacking}')
print(f'Stacking Regressor R2 Score: {r2_stacking}')
"""

import pandas as pd
from rdkit import Chem
from rdkit.ML.Descriptors import MoleculeDescriptors
from rdkit.Chem import rdMolDescriptors
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, StackingRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from xgboost import XGBRegressor

# Load dataset
data = pd.read_csv('aqSol.csv')

# Extract SMILES and solubility (log S) values
smiles_list = data['smiles'].tolist()
solubility = data['log S'].tolist()

# Initialize the descriptor calculator with all available descriptors
descriptor_names = rdMolDescriptors.Properties.GetAvailableProperties()
featurizer = MoleculeDescriptors.MolecularDescriptorCalculator(descriptor_names)

# Calculate descriptors for each molecule
descriptors = [featurizer.CalcDescriptors(Chem.MolFromSmiles(smiles)) for smiles in smiles_list]

# Convert descriptors to a DataFrame
descriptors_df = pd.DataFrame(descriptors, columns=descriptor_names)

# Prepare data for modeling
X = descriptors_df
y = solubility

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Random Forest hyperparameter tuning
rf_param_grid = {
    'n_estimators': [100, 200],
    'max_depth': [10, 20],
    'min_samples_split': [2, 10],
    'min_samples_leaf': [1, 2]
}
rf = RandomForestRegressor(random_state=42)
rf_random = RandomizedSearchCV(rf, param_distributions=rf_param_grid, n_iter=10, cv=3, n_jobs=-1, random_state=42, verbose=2)
rf_random.fit(X_train, y_train)
best_rf = rf_random.best_estimator_
print(f"Best RandomForest Parameters: {rf_random.best_params_}")

# Gradient Boosting hyperparameter tuning
gb_param_grid = {
    'n_estimators': [100, 200],
    'learning_rate': [0.01, 0.1],
    'max_depth': [5, 7]
}
gb = GradientBoostingRegressor(random_state=42)
gb_random = RandomizedSearchCV(gb, param_distributions=gb_param_grid, n_iter=10, cv=3, n_jobs=-1, random_state=42, verbose=2)
gb_random.fit(X_train, y_train)
best_gb = gb_random.best_estimator_
print(f"Best GradientBoosting Parameters: {gb_random.best_params_}")

# XGBoost hyperparameter tuning
xgb_param_grid = {
    'n_estimators': [100, 200],
    'learning_rate': [0.01, 0.1],
    'max_depth': [5, 7],
    'subsample': [0.6, 0.8],
    'gamma': [0, 0.5]
}
xgb = XGBRegressor(random_state=42)
xgb_random = RandomizedSearchCV(xgb, param_distributions=xgb_param_grid, n_iter=10, cv=3, n_jobs=-1, random_state=42, verbose=2)
xgb_random.fit(X_train, y_train)
best_xgb = xgb_random.best_estimator_
print(f"Best XGBoost Parameters: {xgb_random.best_params_}")

# Define the stacking model
stacking_regressor = StackingRegressor(
    estimators=[('rf', best_rf), ('gb', best_gb), ('xgb', best_xgb)],
    final_estimator=LinearRegression(),
    cv=3
)

# Fit the stacking model
stacking_regressor.fit(X_train, y_train)

# Make predictions and evaluate
y_pred_stack = stacking_regressor.predict(X_test)
mse_stack = mean_squared_error(y_test, y_pred_stack)
r2_stack = r2_score(y_test, y_pred_stack)

print(f"Stacking Regressor Mean Squared Error: {mse_stack}")
print(f"Stacking Regressor R2 Score: {r2_stack}")
