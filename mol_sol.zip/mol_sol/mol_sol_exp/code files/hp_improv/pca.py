import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.ML.Descriptors import MoleculeDescriptors
from rdkit.Chem import rdMolDescriptors
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.decomposition import PCA
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import RandomizedSearchCV

# Load the dataset
file_path = 'aqSol.csv'
data = pd.read_csv(file_path)

# Extract SMILES and solubility (log S) values
smiles_list = data['smiles'].tolist()
solubility = data['log S'].tolist()

# Initialize the descriptor calculator with all available descriptors
descriptor_names = rdMolDescriptors.Properties.GetAvailableProperties()
featurizer = MoleculeDescriptors.MolecularDescriptorCalculator(descriptor_names)

# Calculate descriptors for each molecule
descriptors = [featurizer.CalcDescriptors(Chem.MolFromSmiles(smiles)) for smiles in smiles_list]

# Convert descriptors to a DataFrame
descriptors_df = pd.DataFrame(descriptors, columns=descriptor_names)

# Remove highly correlated features (optional, but you can leave it here)
corr_matrix = descriptors_df.corr().abs()
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))

# Drop features with a correlation higher than 0.95
to_drop = [column for column in upper.columns if any(upper[column] > 0.95)]
descriptors_df_reduced = descriptors_df.drop(to_drop, axis=1)

# Apply PCA for dimensionality reduction
pca = PCA(n_components=0.95)  # Keep 95% of the variance
X_pca = pca.fit_transform(descriptors_df_reduced)

# Prepare data for modeling
X = X_pca
y = solubility

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define the parameter grid for RandomForestRegressor
param_grid = {
    'n_estimators': [100, 200, 300, 500],
    'max_depth': [10, 20, 30, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
}

# Initialize the RandomForestRegressor
rf = RandomForestRegressor(random_state=42)

# Perform RandomizedSearchCV
rf_random = RandomizedSearchCV(estimator=rf, param_distributions=param_grid, n_iter=100, cv=3, verbose=2, random_state=42, n_jobs=-1)
rf_random.fit(X_train, y_train)

# Get the best parameters
best_params = rf_random.best_params_
print(f"Best parameters: {best_params}")

# Train the model with best parameters
best_rf = rf_random.best_estimator_
y_pred_best = best_rf.predict(X_test)

# Evaluate the model
mse_best = mean_squared_error(y_test, y_pred_best)
r2_best = r2_score(y_test, y_pred_best)

print(f"PCA Reduced Features Mean Squared Error: {mse_best}")
print(f"PCA Reduced Features R2 Score: {r2_best}")
