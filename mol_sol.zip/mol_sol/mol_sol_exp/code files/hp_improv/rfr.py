import pandas as pd
from rdkit import Chem
from rdkit.ML.Descriptors import MoleculeDescriptors
from rdkit.Chem import rdMolDescriptors
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score

#loading the dataset
file_path = 'aqSol.csv'
data = pd.read_csv(file_path)

# Extract SMILES and solubility (log S) values
smiles_list = data['smiles'].tolist()
solubility = data['log S'].tolist()

# Initialize the descriptor calculator with all available descriptors
descriptor_names = rdMolDescriptors.Properties.GetAvailableProperties()
featurizer = MoleculeDescriptors.MolecularDescriptorCalculator(descriptor_names)

# Calculate descriptors for each molecule
descriptors = [featurizer.CalcDescriptors(Chem.MolFromSmiles(smiles)) for smiles in smiles_list]

# Convert descriptors to a DataFrame
descriptors_df = pd.DataFrame(descriptors, columns=descriptor_names)


# Prepare data for modeling
X = descriptors_df
y = solubility

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train a RandomForestRegressor model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Make predictions on the test set
y_pred = model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f'Mean Squared Error: {mse}')
print(f'R2 Score: {r2}')



