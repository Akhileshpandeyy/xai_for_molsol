import pandas as pd
import numpy as np 
from rdkit import Chem
from rdkit.ML.Descriptors import MoleculeDescriptors
from rdkit.Chem import rdMolDescriptors
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, StackingRegressor, AdaBoostRegressor
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Loading the dataset
file_path = 'aqSol.csv'
data = pd.read_csv(file_path)

# Extract SMILES and solubility (log S) values
smiles_list = data['smiles'].tolist()
solubility = data['log S'].tolist()

# Initialize the descriptor calculator with all available descriptors
descriptor_names = rdMolDescriptors.Properties.GetAvailableProperties()
featurizer = MoleculeDescriptors.MolecularDescriptorCalculator(descriptor_names)

# Calculate descriptors for each molecule
descriptors = [featurizer.CalcDescriptors(Chem.MolFromSmiles(smiles)) for smiles in smiles_list]

# Convert descriptors to a DataFrame
descriptors_df = pd.DataFrame(descriptors, columns=descriptor_names)

# Remove highly correlated features
corr_matrix = descriptors_df.corr().abs()
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))

# Drop features with a correlation higher than 0.95
to_drop = [column for column in upper.columns if any(upper[column] > 0.95)]
descriptors_df_reduced = descriptors_df.drop(to_drop, axis=1)

print(f"Reduced features from {descriptors_df.shape[1]} to {descriptors_df_reduced.shape[1]}")

# Prepare data for modeling
X = descriptors_df_reduced
y = solubility

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define base models
base_models = [
    ('random_forest', RandomForestRegressor(n_estimators=200, max_depth=20, min_samples_split=5, min_samples_leaf=1, max_features='sqrt', random_state=42)),
    ('xgboost', XGBRegressor(n_estimators=500, learning_rate=0.01, max_depth=7, subsample=0.6, gamma=0.5, colsample_bytree=1.0, random_state=42)),
    ('gradient_boosting', GradientBoostingRegressor(n_estimators=300, learning_rate=0.05, max_depth=7, random_state=42)),
    ('linear_regression', Ridge())
]

# Define the meta-model
meta_model = Ridge()

# Define the stacking regressor
stacking_regressor = StackingRegressor(estimators=base_models, final_estimator=meta_model, cv=5, n_jobs=-1)

# Fit the stacking regressor
stacking_regressor.fit(X_train, y_train)

# Make predictions on the test set
y_pred_stack = stacking_regressor.predict(X_test)

# Evaluate the model
mse_stack = mean_squared_error(y_test, y_pred_stack)
r2_stack = r2_score(y_test, y_pred_stack)

print(f'Stacking Regressor Mean Squared Error: {mse_stack}')
print(f'Stacking Regressor R2 Score: {r2_stack}')
