#SHAP
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors

# Load your dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/phys_cure1.csv'  # Update with the correct file path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()  # Replace 'smiles' with the actual column name if different

# Convert SMILES strings to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to a DataFrame with proper descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with the target variable
final_data = pd.concat([features_df, data['log S'].iloc[:len(features_df)]], axis=1)  # Replace 'log S' if your column name differs

# Save the featurized data (optional)
final_data.to_csv('featurized_data_phys_new.csv', index=False)
print(final_data.head())

import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Load the featurized data
featurized_data = pd.read_csv('featurized_data_phys_new.csv')

# Drop rows with missing values
featurized_data = featurized_data.dropna()

# Split features and target
X = featurized_data.drop('log S', axis=1)  # Replace 'log S' with your actual target column name
y = featurized_data['log S']

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)


import shap
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from catboost import CatBoostRegressor
import joblib  # For saving models

# =============== Train All Models =============== #
# Initialize models
models = {
   # "Linear Regression": LinearRegression(),
    #"Random Forest": RandomForestRegressor(n_estimators=100, random_state=42),
    "CatBoost": CatBoostRegressor(verbose=0, random_seed=42),
    #"SVR": SVR()
}

# Train models
for name, model in models.items():
    print(f"Training {name}...")
    model.fit(X_train_scaled, y_train)
    joblib.dump(model, f"{name.replace(' ', '_').lower()}_model.pkl")  # Save trained model

# =============== Apply SHAP to All Models =============== #
for name, model in models.items():
    print(f"\n🔹 Applying SHAP to {name}...")

    # Initialize SHAP explainer
    if name in ["Random Forest", "CatBoost"]:
        explainer = shap.TreeExplainer(model)  # TreeExplainer for tree-based models
        shap_values = explainer.shap_values(X_test_scaled)
    else:
        explainer = shap.KernelExplainer(model.predict, X_train_scaled[:50])  # KernelExplainer for non-tree models
        shap_values = explainer.shap_values(X_test_scaled[:50])  # Use a subset to reduce computation time

    # Save SHAP values as CSV
    shap_df = pd.DataFrame(shap_values, columns=X.columns)
    shap_df.to_csv(f"phys_shap_values{name.replace(' ', '_').lower()}.csv", index=False)

    # ==========================
    # 🔹 Global Explanation (SHAP Summary Plots)
    # ==========================
    plt.figure()
    if name in ["Linear Regression", "SVR"]:
       shap.summary_plot(shap_values, X_test_scaled[:50], feature_names=X.columns, show=False)  # Match subset
    else:
       shap.summary_plot(shap_values, X_test_scaled, feature_names=X.columns, show=False)

    plt.savefig(f"phys_shap_summary_{name.replace(' ', '_').lower()}.png", dpi=300, bbox_inches="tight")
    plt.close()

    # ==========================
    # 🔹 Global Explanation (SHAP Summary Bar Plot)
    # ==========================
    plt.figure()
    shap.summary_plot(shap_values, X_test_scaled, feature_names=X.columns, plot_type="bar", show=False)
    plt.savefig(f"phys_shap_global_bar_plot_{name.replace(' ', '_').lower()}.png", dpi=300, bbox_inches="tight")
    plt.close()


    # ==========================
    # 🔹 Local Explanation (SHAP Force Plot)
    # ==========================
    index = 0  # Change index to analyze different molecules
    shap.initjs()
    force_plot = shap.force_plot(
        explainer.expected_value,
        shap_values[index],
        feature_names=X.columns
    )
    
    shap.save_html(f"phys_shap_force_plot_{name.replace(' ', '_').lower()}.html", force_plot)

print("\n✅ SHAP analysis complete! Results saved.")
"""



import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load your dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/esol_cure1.csv'  # Update with the correct file path
df = pd.read_csv(data_path)

# The solubility column is 'log S'
log_s_column = 'log S'

# Generate the plot
plt.figure(figsize=(10, 6))
# Create a histogram with a Kernel Density Estimate (KDE) line
sns.histplot(df[log_s_column], kde=True, bins=30, color='#6495ED') 

# Set title and labels using LaTeX for Log S for a professional look
plt.title(r'Distribution of $\log S$ (Aqueous Solubility)', fontsize=16)
plt.xlabel(r'Measured $\log S$ (mol/L)', fontsize=14)
plt.ylabel('Frequency (Number of Molecules)', fontsize=14)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()

# Save the plot
plt.savefig('esol_logS_distribution_graph.png')
plt.close()



#LIME
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
import joblib  # For saving and loading models
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from catboost import CatBoostRegressor
import lime
import lime.lime_tabular
import matplotlib.pyplot as plt

# ========== Step 1: Load and Featurize Data ==========
# Load your dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'  # Update the file path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()

# Convert SMILES to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to a DataFrame with proper descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with the target variable and SMILES
final_data = pd.concat([data[['smiles', 'log S']], features_df], axis=1)

# Save featurized data
final_data.to_csv('featurized_data_aqua.csv', index=False)
print("✅ Featurization complete!")

# ========== Step 2: Split Data and Track SMILES ==========
# Drop rows with missing values
final_data = final_data.dropna()

# Preserve SMILES before dropping them from features
X = final_data.drop(['log S', 'smiles'], axis=1)
y = final_data['log S']
smiles = final_data['smiles']

# Split data into training and test sets
X_train, X_test, y_train, y_test, smiles_train, smiles_test = train_test_split(
    X, y, smiles, test_size=0.2, random_state=42
)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Convert X_test_scaled to DataFrame with index mapped to SMILES
X_test_scaled_df = pd.DataFrame(X_test_scaled, columns=X.columns, index=smiles_test.index)

# Save mapping of SMILES to test set for reference
test_data_with_smiles = pd.DataFrame({'SMILES': smiles_test, 'Actual Solubility': y_test}).reset_index(drop=True)
test_data_with_smiles.to_csv("test_molecules_with_smiles.csv", index=False)
print("✅ Data splitting complete! Test molecules saved.")

# ========== Step 3: Train Models ==========
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=100, random_state=42),
    "CatBoost": CatBoostRegressor(verbose=0, random_seed=42),
    "SVR": SVR()
}

# Train models and save them
for name, model in models.items():
    print(f"Training {name}...")
    model.fit(X_train_scaled, y_train)
    joblib.dump(model, f"{name.replace(' ', '_').lower()}_model.pkl")  # Save trained model
print("✅ Model training complete!")

# ========== Step 4: Apply LIME ==========
# Select a molecule for explanation (manually choose based on SMILES)
selected_smiles = "OCC(O)C(O)CO"  # Replace with any molecule you want to analyze

# Check if the selected SMILES exists in the test dataset
if selected_smiles in test_data_with_smiles['SMILES'].values:
    selected_index = test_data_with_smiles[test_data_with_smiles['SMILES'] == selected_smiles].index[0]

    # Extract the test molecule's scaled features
    sample = X_test_scaled[selected_index].reshape(1, -1)

    print(f"✅ Selected molecule {selected_smiles} found in test set.")

    # Initialize LIME explainer
    lime_explainer = lime.lime_tabular.LimeTabularExplainer(
        X_train_scaled,
        feature_names=X.columns,
        class_names=["Solubility"],
        mode="regression"
    )

    # Apply LIME to all models
    for name, model in models.items():
        print(f"\n🔹 Applying LIME to {name}...")

        # Explain the chosen sample
        exp = lime_explainer.explain_instance(sample[0], model.predict, num_features=10)

        # Save explanation as HTML
        exp.save_to_file(f"lime_explanation_{name.replace(' ', '_').lower()}.html")

        # Save explanation as PNG
        fig = exp.as_pyplot_figure()
        plt.savefig(f"lime_plot_{name.replace(' ', '_').lower()}.png", dpi=300, bbox_inches="tight")
        plt.close()

    print("\n✅ LIME analysis complete! Explanations saved.")

else:
    print(f"❌ Error: Molecule {selected_smiles} not found in test set! Please check test_molecules_with_smiles.csv and choose a valid SMILES.")
"""




#PDP
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
import joblib  # For saving and loading models
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from catboost import CatBoostRegressor
import matplotlib.pyplot as plt
from sklearn.inspection import partial_dependence, PartialDependenceDisplay

# ========== Step 1: Load and Featurize Data ==========
# Load dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'  # Update the path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()

# Convert SMILES to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to DataFrame with descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with target variable and SMILES
final_data = pd.concat([data[['smiles', 'log S']], features_df], axis=1)

# Save featurized data
final_data.to_csv('featurized_data_aqua.csv', index=False)
print("✅ Featurization complete!")

# ========== Step 2: Split Data and Track SMILES ==========
# Drop rows with missing values
final_data = final_data.dropna()

# Preserve SMILES before dropping from features
X = final_data.drop(['log S', 'smiles'], axis=1)
y = final_data['log S']
smiles = final_data['smiles']

# Split data into training and test sets
X_train, X_test, y_train, y_test, smiles_train, smiles_test = train_test_split(
    X, y, smiles, test_size=0.2, random_state=42
)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Convert X_test_scaled to DataFrame with index mapped to SMILES
X_test_scaled_df = pd.DataFrame(X_test_scaled, columns=X.columns, index=smiles_test.index)

# Save mapping of SMILES to test set for reference
test_data_with_smiles = pd.DataFrame({'SMILES': smiles_test, 'Actual Solubility': y_test}).reset_index(drop=True)
test_data_with_smiles.to_csv("test_molecules_with_smiles.csv", index=False)
print("✅ Data splitting complete! Test molecules saved.")

# ========== Step 3: Train Models ==========
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=100, random_state=42),
    "CatBoost": CatBoostRegressor(verbose=0, random_seed=42),
    "SVR": SVR()
}

# Train models and save them
for name, model in models.items():
    print(f"Training {name}...")
    model.fit(X_train_scaled, y_train)
    joblib.dump(model, f"{name.replace(' ', '_').lower()}_model.pkl")  # Save trained model
print("✅ Model training complete!")

# ========== Step 4: Apply PDP (Partial Dependence Plots) ==========
# Select important features to analyze with PDP
selected_features = [ "PEOE_VSA3"]  # Modify based on prior SHAP/LIME results

# Apply PDP to all models
for name, model in models.items():
    print(f"\n🔹 Generating PDP for {name}...")

    for feature in selected_features:
        if feature not in X.columns:
            print(f"❌ Feature {feature} not found in dataset! Skipping...")
            continue

        feature_index = list(X.columns).index(feature)  # Find feature index

        # Compute PDP
        pdp_results = partial_dependence(model, X_test_scaled, features=[feature_index])

        # Plot PDP
        fig, ax = plt.subplots(figsize=(6, 4))
        PartialDependenceDisplay.from_estimator(model, X_test_scaled, [feature_index], feature_names=X.columns, ax=ax)
        plt.title(f"PDP for {feature} - {name}")
        plt.savefig(f"pdp_{feature}_{name.replace(' ', '_').lower()}.png", dpi=300, bbox_inches="tight")
        plt.close()

print("\n✅ PDP analysis complete! Plots saved.")
"""




#permutation importance
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
import joblib  # For saving and loading models
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from catboost import CatBoostRegressor
import matplotlib.pyplot as plt
from sklearn.inspection import permutation_importance

# ========== Step 1: Load and Featurize Data ==========
# Load dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'  # Update the path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()

# Convert SMILES to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to DataFrame with descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with target variable and SMILES
final_data = pd.concat([data[['smiles', 'log S']], features_df], axis=1)

# Save featurized data
final_data.to_csv('featurized_data_aqua.csv', index=False)
print("✅ Featurization complete!")

# ========== Step 2: Split Data and Track SMILES ==========
# Drop rows with missing values
final_data = final_data.dropna()

# Preserve SMILES before dropping from features
X = final_data.drop(['log S', 'smiles'], axis=1)
y = final_data['log S']
smiles = final_data['smiles']

# Split data into training and test sets
X_train, X_test, y_train, y_test, smiles_train, smiles_test = train_test_split(
    X, y, smiles, test_size=0.2, random_state=42
)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Convert X_test_scaled to DataFrame with index mapped to SMILES
X_test_scaled_df = pd.DataFrame(X_test_scaled, columns=X.columns, index=smiles_test.index)

# Save mapping of SMILES to test set for reference
test_data_with_smiles = pd.DataFrame({'SMILES': smiles_test, 'Actual Solubility': y_test}).reset_index(drop=True)
test_data_with_smiles.to_csv("test_molecules_with_smiles.csv", index=False)
print("✅ Data splitting complete! Test molecules saved.")

# ========== Step 3: Train Models ==========
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=100, random_state=42),
    "CatBoost": CatBoostRegressor(verbose=0, random_seed=42),
    "SVR": SVR()
}

# Train models and save them
for name, model in models.items():
    print(f"Training {name}...")
    model.fit(X_train_scaled, y_train)
    joblib.dump(model, f"{name.replace(' ', '_').lower()}_model.pkl")  # Save trained model
print("✅ Model training complete!")

# ========== Step 4: Apply Permutation Importance ==========
# Store feature importance results
importance_results = {}

# Apply Permutation Importance to all models
for name, model in models.items():
    print(f"\n🔹 Computing Permutation Importance for {name}...")

    # Compute Permutation Importance
    perm_importance = permutation_importance(model, X_test_scaled, y_test, n_repeats=10, random_state=42)

    # Store results
    feature_importance_df = pd.DataFrame({
        "Feature": X.columns,
        "Importance": perm_importance.importances_mean
    }).sort_values(by="Importance", ascending=False)

    # Save as CSV
    feature_importance_df.to_csv(f"permutation_importance_{name.replace(' ', '_').lower()}.csv", index=False)

    # Store in dictionary for analysis
    importance_results[name] = feature_importance_df

    # ==========================
    # 🔹 Save Permutation Importance Bar Plot
    # ==========================
    plt.figure(figsize=(8, 6))
    plt.barh(feature_importance_df["Feature"][:10], feature_importance_df["Importance"][:10], color='skyblue')
    plt.xlabel("Feature Importance")
    plt.ylabel("Features")
    plt.title(f"Permutation Importance - {name}")
    plt.gca().invert_yaxis()
    plt.savefig(f"permutation_importance_{name.replace(' ', '_').lower()}.png", dpi=300, bbox_inches="tight")
    plt.close()

print("\n✅ Permutation Importance analysis complete! Results saved.")
"""






#clustering molecules based on solubility value  
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
import joblib  # For saving and loading models
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from catboost import CatBoostRegressor
import matplotlib.pyplot as plt
from sklearn.inspection import partial_dependence, PartialDependenceDisplay

# ========== Step 1: Load and Featurize Data ==========
# Load dataset
data_path = '/content/drive/MyDrive/mol_sol/xai_for_mol_sol/aqsol_cure1copy.csv'  # Update the path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()

# Convert SMILES to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to DataFrame with descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with target variable and SMILES
final_data = pd.concat([data[['smiles', 'log S']], features_df], axis=1)

# Save featurized data
final_data.to_csv('featurized_data_aqsol_new.csv', index=False)
print("✅ Featurization complete!")

# ========== Step 2: Clustering the Featurized Data according to its solubility value ==========

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from catboost import CatBoostRegressor, Pool
from sklearn.metrics import mean_squared_error, r2_score
import shap
import matplotlib.pyplot as plt
import joblib

# Load the featurized dataset
df = pd.read_csv('featurized_data_aqsol_new.csv')

# Quantile thresholds for clustering
low_thresh = df['log S'].quantile(0.33)
high_thresh = df['log S'].quantile(0.66)

# Define solubility classes
def assign_class(logs):
    if logs <= low_thresh:
        return 'low'
    elif logs <= high_thresh:
        return 'medium'
    else:
        return 'high'

# Apply to dataset
df['solubility_class'] = df['log S'].apply(assign_class)

# Check and print distribution
print("\n📊 Cluster Distribution:")
print(df['solubility_class'].value_counts())

# Save this updated dataset (optional)
df.to_csv('featurized_clustered_aqsol.csv', index=False)

# Drop non-feature columns
feature_cols = df.columns.difference(['smiles', 'log S', 'solubility_class'])

# Store results
performance_results = []

# Function to train, explain, and evaluate per cluster
def train_catboost_with_split_and_shap(cluster_label):
    print(f"\n🔍 Processing: {cluster_label.upper()} class")

    # Filter data
    cluster_df = df[df['solubility_class'] == cluster_label]
    X = cluster_df[feature_cols]
    y = cluster_df['log S']

    # Split into train and test
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Train CatBoost model
    model = CatBoostRegressor(verbose=0, random_state=42)
    model.fit(X_train, y_train)

    # Save model
    joblib.dump(model, f'catboost_{cluster_label}.pkl')

    # Predict and evaluate
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)

    print(f"📈 Metrics for {cluster_label.upper()} cluster:")
    print(f"  - MSE  = {mse:.4f}")
    print(f"  - RMSE = {rmse:.4f}")
    print(f"  - R²   = {r2:.4f}")

    # SHAP values
    shap_values = model.get_feature_importance(Pool(X_test, label=y_test), type='ShapValues')
    shap_vals = shap_values[:, :-1]  # exclude expected value column

    # SHAP summary plot
    shap.summary_plot(shap_vals, features=X_test, feature_names=feature_cols, show=False)
    plt.title(f"SHAP Summary - {cluster_label.upper()} Solubility")
    plt.tight_layout()
    plt.savefig(f'shap_summary_{cluster_label}.png')
    plt.close()
    print(f"✅ SHAP plot saved: shap_summary_{cluster_label}.png")

    # Store results
    return {
        "Cluster": cluster_label,
        "MSE": mse,
        "RMSE": rmse,
        "R2": r2
    }

# Run for each cluster and collect results
for cluster in ['low', 'medium', 'high']:
    result = train_catboost_with_split_and_shap(cluster)
    performance_results.append(result)

# Print performance summary
performance_df = pd.DataFrame(performance_results)
print("\n📊 Final Performance Summary:")
print(performance_df)
"""




#2D PDP plots
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
import joblib  # For saving and loading models
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from catboost import CatBoostRegressor
import matplotlib.pyplot as plt
from sklearn.inspection import partial_dependence, PartialDependenceDisplay

# ========== Step 1: Load and Featurize Data ==========
# Load dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'  # Update the path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()

# Convert SMILES to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to DataFrame with descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with target variable and SMILES
final_data = pd.concat([data[['smiles', 'log S']], features_df], axis=1)

# Save featurized data
final_data.to_csv('featurized_data_aqua.csv', index=False)
print("✅ Featurization complete!")

# ========== Step 2: Split Data and Track SMILES ==========
# Drop rows with missing values
final_data = final_data.dropna()

# Preserve SMILES before dropping from features
X = final_data.drop(['log S', 'smiles'], axis=1)
y = final_data['log S']
smiles = final_data['smiles']

# Split data into training and test sets
X_train, X_test, y_train, y_test, smiles_train, smiles_test = train_test_split(
    X, y, smiles, test_size=0.2, random_state=42
)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Convert X_test_scaled to DataFrame with index mapped to SMILES
X_test_scaled_df = pd.DataFrame(X_test_scaled, columns=X.columns, index=smiles_test.index)

# Save mapping of SMILES to test set for reference
test_data_with_smiles = pd.DataFrame({'SMILES': smiles_test, 'Actual Solubility': y_test}).reset_index(drop=True)
test_data_with_smiles.to_csv("test_molecules_with_smiles.csv", index=False)
print("✅ Data splitting complete! Test molecules saved.")

# ========== Step 3: Train Models ==========
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=100, random_state=42),
    "CatBoost": CatBoostRegressor(verbose=0, random_seed=42),
    "SVR": SVR()
}

# Train models and save them
for name, model in models.items():
    print(f"Training {name}...")
    model.fit(X_train_scaled, y_train)
    joblib.dump(model, f"{name.replace(' ', '_').lower()}_model.pkl")  # Save trained model
print("✅ Model training complete!")

# ========== Step 4: Apply 2D PDP for Feature Interactions ==========
# Define the feature pair you want to investigate
feature_pair = ("PEOE_VSA4", "HallKierAlpha")

# Check if both features are present
if all(f in X.columns for f in feature_pair):
    feature_indices = [list(X.columns).index(f) for f in feature_pair]

    for name, model in models.items():
        print(f"\n🔹 Generating 2D PDP for {name}...")

        # Compute PDP
        pdp_results = partial_dependence(
            model,
            X_test_scaled,
            features=[tuple(feature_indices)],  # ✅ FIXED HERE
            kind='average',
            grid_resolution=20
        )

        # Plot PDP
        fig, ax = plt.subplots(figsize=(6, 5))
        PartialDependenceDisplay.from_estimator(
            model,
            X_test_scaled,
            features=[tuple(feature_indices)],
            feature_names=X.columns,
            ax=ax
        )
        plt.title(f"2D PDP: {feature_pair[0]} vs {feature_pair[1]} - {name}")
        plt.tight_layout()
        plt.savefig(f"2dpdp_{feature_pair[0]}_{feature_pair[1]}_{name.replace(' ', '_').lower()}.png", dpi=300)
        plt.close()
else:
    print(f"❌ One or both features not found in the dataset: {feature_pair}")
"""



#peoevsa4 + hallkeiralpha interaction
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
from sklearn.inspection import PartialDependenceDisplay

# Step 1: Load and Featurize
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'
data = pd.read_csv(data_path)

featurizer = dc.feat.RDKitDescriptors()
smiles_list = data['smiles'].tolist()
molecules = [Chem.MolFromSmiles(smi) for smi in smiles_list]
valid_molecules = [mol for mol in molecules if mol is not None]
features = featurizer.featurize(valid_molecules)
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]
features_df = pd.DataFrame(features, columns=descriptor_names)

final_data = pd.concat([features_df, data['log S'].iloc[:len(features_df)]], axis=1)
final_data.to_csv('featurized_data_aqua.csv', index=False)
print("✅ Featurization complete.")

# Step 2: Drop NA and Define Features
df = final_data.dropna()
X = df.drop('log S', axis=1)
y = df['log S']

# Step 3: PDP-Inspired Feature Engineering
if 'PEOE_VSA4' in X.columns and 'HallKierAlpha' in X.columns:
    X['PEOE_VSA4_bin'] = pd.cut(X['PEOE_VSA4'], bins=[-np.inf, 0.1, 0.2, np.inf], labels=[0, 1, 2])
    X['HallKierAlpha_squared'] = X['HallKierAlpha'] ** 2
    X['PEOE_HKA_interaction'] = X['PEOE_VSA4'] * X['HallKierAlpha']
else:
    raise ValueError("Required descriptors not found!")

# Step 4: Train/Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 5: Scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Step 6: Train CatBoost on engineered features
model = CatBoostRegressor(verbose=0, random_seed=42)
model.fit(X_train_scaled, y_train)

# Step 7: Evaluation
y_pred = model.predict(X_test_scaled)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

print("\n🎯 Model Performance with Engineered Features:")
print(f"R² Score: {r2:.4f}")
print(f"MSE: {mse:.4f}")
print(f"RMSE: {rmse:.4f}")

# Step 8: Compare PDPs Before/After
feature_pairs = ['PEOE_VSA4', 'HallKierAlpha', 'PEOE_HKA_interaction']
for feat in feature_pairs:
    if feat in X.columns:
        idx = list(X.columns).index(feat)
        fig, ax = plt.subplots(figsize=(6, 4))
        PartialDependenceDisplay.from_estimator(model, X_test_scaled, [idx], feature_names=X.columns, ax=ax)
        plt.title(f"PDP - {feat}")
        plt.savefig(f"pdp_engineered_{feat}.png", dpi=300, bbox_inches='tight')
        plt.close()

print("📊 PDP plots for engineered features saved.")


import shap
import matplotlib.pyplot as plt
import pandas as pd

# Initialize SHAP explainer for CatBoost
explainer = shap.TreeExplainer(model)

# Apply SHAP on the scaled test set
shap_values = explainer.shap_values(X_test_scaled)

# Create DataFrame for SHAP values
shap_df = pd.DataFrame(shap_values, columns=X.columns)

# Save SHAP values to CSV
shap_df.to_csv("shap_values_catboost_engineered.csv", index=False)
print("✅ SHAP values saved to shap_values_catboost_engineered.csv")

# 🔹 SHAP Summary Plot
plt.figure()
shap.summary_plot(shap_values, X_test_scaled, feature_names=X.columns, show=False)
plt.title("SHAP Summary - CatBoost with Engineered Features")
plt.savefig("shap_summary_catboost_engineered.png", dpi=300, bbox_inches='tight')
plt.close()
print("📊 SHAP summary plot saved: shap_summary_catboost_engineered.png")

# 🔹 SHAP Bar Plot
plt.figure()
shap.summary_plot(shap_values, X_test_scaled, feature_names=X.columns, plot_type="bar", show=False)
plt.title("SHAP Feature Importance (Bar)")
plt.savefig("shap_bar_catboost_engineered.png", dpi=300, bbox_inches='tight')
plt.close()
print("📊 SHAP bar plot saved: shap_bar_catboost_engineered.png")
"""


"""
import pandas as pd
import numpy as np
import shap
import joblib
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import os

# Load original featurized data
df = pd.read_csv("featurized_data_aqua.csv").dropna()
X = df.drop(columns=["log S"])
y = df["log S"]

# Define transformations to try
transformations = [
    ("HallKierAlpha_squared", lambda df: df["HallKierAlpha"] ** 2, "Non-linear"),
    ("PEOE_HKA_interaction", lambda df: df["PEOE_VSA4"] * df["HallKierAlpha"], "Interaction"),
    # Add more transformations below as needed
]

# Create or load performance log
log_file = "feature_engineering_log.csv"
if os.path.exists(log_file):
    log_df = pd.read_csv(log_file)
else:
    log_df = pd.DataFrame(columns=["Iteration", "Engineered Feature(s)", "Feature Type", "R2", "RMSE", "SHAP Rank", "Notes"])

# Iterate over transformations
for idx, (feat_name, func, ftype) in enumerate(transformations, start=len(log_df)+1):
    print(f"\n🔧 Iteration {idx} — Adding Feature: {feat_name}")

    # Add engineered feature
    X[feat_name] = func(X)

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Scale
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Train model
    model = CatBoostRegressor(verbose=0, random_state=42)
    model.fit(X_train_scaled, y_train)

    # Predict
    preds = model.predict(X_test_scaled)
    r2 = r2_score(y_test, preds)
    rmse = np.sqrt(mean_squared_error(y_test, preds))

    # SHAP
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_test_scaled)
    mean_abs_shap = np.abs(shap_values).mean(axis=0)
    shap_rank = pd.Series(mean_abs_shap, index=X.columns).sort_values(ascending=False)
    
    rank = shap_rank.index.get_loc(feat_name) + 1 if feat_name in shap_rank.index else "N/A"

    # Append log
    log_df.loc[len(log_df)] = {
        "Iteration": idx,
        "Engineered Feature(s)": feat_name,
        "Feature Type": ftype,
        "R2": round(r2, 4),
        "RMSE": round(rmse, 4),
        "SHAP Rank": rank,
        "Notes": ""
    }

    print(f"✅ Added: {feat_name} | R²: {r2:.4f} | RMSE: {rmse:.4f} | SHAP Rank: {rank}")

# Save log
log_df.to_csv(log_file, index=False)
print("\n📊 Performance log updated and saved as 'feature_engineering_log.csv'")
"""







#autoencoders
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors

# Load your dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'  # Update with the correct file path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()  # Replace 'smiles' with the actual column name if different

# Convert SMILES strings to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to a DataFrame with proper descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with the target variable
final_data = pd.concat([features_df, data['log S'].iloc[:len(features_df)]], axis=1)  # Replace 'log S' if your column name differs

# Save the featurized data (optional)
final_data.to_csv('featurized_data_aqua.csv', index=False)
print(final_data.head())

import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Load the featurized data
featurized_data = pd.read_csv('featurized_data_aqua.csv')

# Drop rows with missing values
featurized_data = featurized_data.dropna()

# Split features and target
X = featurized_data.drop('log S', axis=1)  # Replace 'log S' with your actual target column name
y = featurized_data['log S']

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

# Define input dimension
input_dim = X_train_scaled.shape[1]

# Define autoencoder architecture
encoding_dim = 30  # You can adjust this (e.g., try 16, 32, etc.)
input_layer = Input(shape=(input_dim,))

# Encoder
encoded = Dense(128, activation='relu')(input_layer)
encoded = Dense(64, activation='relu')(encoded)
encoded = Dense(encoding_dim, activation='relu')(encoded)  # Latent representation

# Decoder
decoded = Dense(64, activation='relu')(encoded)
decoded = Dense(128, activation='relu')(decoded)
decoded = Dense(input_dim, activation='linear')(decoded)

# Autoencoder model
autoencoder = Model(inputs=input_layer, outputs=decoded)

# Compile
autoencoder.compile(optimizer=Adam(learning_rate=0.001), loss='mse')

# Train the autoencoder
early_stop = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

autoencoder.fit(X_train_scaled, X_train_scaled,
                epochs=200,
                batch_size=32,
                shuffle=True,
                validation_data=(X_test_scaled, X_test_scaled),
                callbacks=[early_stop],
                verbose=1)

# Create encoder model
encoder = Model(inputs=input_layer, outputs=encoded)

# Generate encoded (compressed) features
X_train_encoded = encoder.predict(X_train_scaled)
X_test_encoded = encoder.predict(X_test_scaled)


# Train CatBoost on latent features
cat_model = CatBoostRegressor(verbose=0)
cat_model.fit(X_train_encoded, y_train)

# Predict and evaluate
y_pred = cat_model.predict(X_test_encoded)

mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"Autoencoder + CatBoost → MSE: {mse:.4f}, R²: {r2:.4f}")

import matplotlib.pyplot as plt

# Plot training and validation loss
history = autoencoder.history

plt.figure(figsize=(8, 5))
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Autoencoder Loss Over Epochs')
plt.xlabel('Epoch')
plt.ylabel('MSE Loss')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# Get encoded features (latent vectors)
X_train_encoded = encoder.predict(X_train_scaled)
X_test_encoded = encoder.predict(X_test_scaled)

from sklearn.decomposition import PCA

# Combine train and test for visualization
X_encoded = np.vstack((X_train_encoded, X_test_encoded))
y_combined = np.hstack((y_train, y_test))

# Apply PCA to the latent space
pca = PCA(n_components=2)
X_pca_2d = pca.fit_transform(X_encoded)

import matplotlib.pyplot as plt

plt.figure(figsize=(8, 6))
scatter = plt.scatter(X_pca_2d[:, 0], X_pca_2d[:, 1], c=y_combined, cmap='viridis', alpha=0.7)
plt.colorbar(scatter, label='Solubility (log S)')
plt.title('PCA on Autoencoder Latent Space')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.grid(True)
plt.tight_layout()
plt.show()
"""


