#structural features:
"""
'NumAliphaticHeterocycles','NumAliphaticRings',	'NumAromaticCarbocycles', 'NumAromaticHeterocycles','NumAromaticRings',	'NumHeteroatoms',	'NumRotatableBonds', 'NumSaturatedHeterocycles', 'NumSaturatedRings', 
'BalabanJ', 'BertzCT', 'Chi0', 'Chi1', 'Chi2n', 'Chi3n', 'Chi4n', 'Chi0v', 'Chi1v', 'Chi2v', 'Chi3v', 'Chi4v'
"""


#electronic properties: 
"""
'MaxAbsEStateIndex','MaxEStateIndex', 'MinAbsEStateIndex',	'MinEStateIndex',	'qed',	'MaxAbsPartialCharge',	'MinAbsPartialCharge',	'EState_VSA1',	
'EState_VSA2',	'EState_VSA3', 'EState_VSA4','EState_VSA5','EState_VSA6','EState_VSA7','EState_VSA8','EState_VSA9', 'EState_VSA10',	'EState_VSA11', 
'VSA_EState1', 'VSA_EState2', 'VSA_EState3', 'VSA_EState4', 'VSA_EState5', 'VSA_EState6', 'VSA_EState7', 'VSA_EState8', 'VSA_EState9', 'VSA_EState10',
'BCUT2D_CHGHI', 'BCUT2D_CHGLO', 'BCUT2D_LOGPHI', 'BCUT2D_LOGPLOW', 'BCUT2D_MRHI', 'BCUT2D_MRLOW', 'BCUT2D_MWHI', 'BCUT2D_MWLOW'
"""


#hydrophobicity and hydrophilicilty:
"""
'MolLogP'
"""


#molecualr size and shape:
"""
'MolWt','HeavyAtomMolWt','ExactMolWt','LabuteASA','PEOE_VSA1','PEOE_VSA10','PEOE_VSA11','PEOE_VSA12',
'PEOE_VSA13','PEOE_VSA14','PEOE_VSA2','PEOE_VSA3','PEOE_VSA4','PEOE_VSA5','PEOE_VSA6','PEOE_VSA7','PEOE_VSA8',
'PEOE_VSA9','SMR_VSA1','SMR_VSA10','SMR_VSA2','SMR_VSA3','SMR_VSA4','SMR_VSA5','SMR_VSA6','SMR_VSA7',
'SMR_VSA8','SMR_VSA9','SlogP_VSA1','SlogP_VSA10','SlogP_VSA11','SlogP_VSA12','SlogP_VSA2','SlogP_VSA3','SlogP_VSA4','SlogP_VSA5',
'SlogP_VSA6','SlogP_VSA7','SlogP_VSA8','SlogP_VSA9','TPSA','HeavyAtomCount',
'FpDensityMorgan1', 'FpDensityMorgan2', 'FpDensityMorgan3', 'FractionCSP3', 'MolMR', 'NHOHCount',
 'NOCount', 'NumHAcceptors', 'NumHDonors', 'NumValenceElectrons'
"""

#miscellaneous
"""
'fr_Al_COO', 'fr_Al_OH', 'fr_Al_OH_noTert', 'fr_ArN', 'fr_Ar_COO', 'fr_Ar_N', 'fr_Ar_NH', 'fr_Ar_OH', 'fr_COO', 'fr_COO2',
'fr_C_O', 'fr_C_O_noCOO', 'fr_C_S', 'fr_HOCCN', 'fr_Imine', 'fr_NH0', 'fr_NH1', 'fr_NH2', 'fr_N_O', 'fr_Ndealkylation1',
'fr_Ndealkylation2', 'fr_Nhpyrrole', 'fr_SH', 'fr_aldehyde', 'fr_alkyl_carbamate', 'fr_alkyl_halide', 'fr_allylic_oxid',
'fr_amide', 'fr_amidine', 'fr_aniline', 'fr_aryl_methyl', 'fr_azide', 'fr_azo', 'fr_barbitur', 'fr_benzene', 'fr_benzodiazepine',
'fr_bicyclic', 'fr_diazo', 'fr_dihydropyridine', 'fr_epoxide', 'fr_ester', 'fr_ether', 'fr_furan', 'fr_guanido', 'fr_halogen',
'fr_hdrzine', 'fr_hdrzone', 'fr_imidazole', 'fr_imide', 'fr_isocyan', 'fr_isothiocyan', 'fr_ketone', 'fr_ketone_Topliss',
'fr_lactam', 'fr_lactone', 'fr_methoxy', 'fr_morpholine', 'fr_nitrile', 'fr_nitro', 'fr_nitro_arom', 'fr_nitro_arom_nonortho',
'fr_nitroso', 'fr_oxazole', 'fr_oxime', 'fr_para_hydroxylation', 'fr_phenol', 'fr_phenol_noOrthoHbond', 'fr_phos_acid',
'fr_phos_ester', 'fr_piperdine', 'fr_piperzine', 'fr_priamide', 'fr_prisulfonamd', 'fr_pyridine', 'fr_quatN', 'fr_sulfide',
'fr_sulfonamd', 'fr_sulfone', 'fr_term_acetylene', 'fr_tetrazole', 'fr_thiazole', 'fr_thiocyan', 'fr_thiophene', 'fr_unbrch_alkane',
'fr_urea', 'Ipc', 'Kappa1', 'Kappa2', 'Kappa3', 'MaxPartialCharge', 'MinPartialCharge', 'NumRadicalElectrons',
 'RingCount'
"""


#top 10 features from each category(phys)
"""
'Chi1v', 'NumHeteroatoms', 'Chi4v', 'NumAromaticRings', 'Chi2n', 'Chi3v', 'NumRotatableBonds', 'NumAliphaticRings', 'NumSaturatedHeterocycles', 'Chi4n',
'EState_VSA6', 'MaxAbsPartialCharge', 'VSA_EState3', 'qed', 'VSA_EState2', 'MinAbsPartialCharge', 'EState_VSA7', 'VSA_EState9', 'BCUT2D_CHGHI', 'BCUT2D_LOGPHI',
'MolLogP',
'PEOE_VSA4', 'PEOE_VSA5', 'LabuteASA', 'HeavyAtomMolWt', 'FpDensityMorgan2', 'PEOE_VSA6', 'PEOE_VSA3', 'PEOE_VSA8', 'SlogP_VSA1', 'FpDensityMorgan1',
'Ipc', 'MinPartialCharge', 'fr_halogen', 'Kappa1', 'fr_benzene', 'NumValenceElectrons', 'MaxPartialCharge', 'fr_Al_OH', 'fr_bicyclic', 'fr_unbrch_alkane' 
"""
#top 10 features from each category(aqsol)
"""
'NumHeteroatoms', 'NumAromaticRings', 'Chi4v', 'Chi3v', 'Chi1v',
'EState_VSA6', 'MinEStateIndex', 'VSA_EState9', 'qed', 'EState_VSA7',
'MolLogP',
'PEOE_VSA4', 'FpDensityMorgan1', 'PEOE_VSA3', 'ExactMolWt', 'MolWt'
"""

#pca top 30
"""
'VSA_EState3', 'SMR_VSA5', 'Chi4n', 'NumAtomStereoCenters', 'SMR_VSA3',
'fr_barbitur', 'VSA_EState9', 'NumUnspecifiedAtomStereoCenters', 'SlogP_VSA1', 'VSA_EState5',
'NumAliphaticRings', 'fr_guanido', 'NumRotatableBonds', 'VSA_EState2', 'Chi1n',
'NOCount', 'SlogP_VSA10', 'fr_Imine', 'PEOE_VSA3', 'PEOE_VSA2',
'HallKierAlpha', 'PEOE_VSA10', 'NumHeteroatoms', 'Chi3v', 'NumRadicalElectrons', 
'VSA_EState10', 'PEOE_VSA6', 'Chi1v', 'PEOE_VSA12', 'SlogP_VSA8'
"""

#feature selection(univariate)
"""
'PEOE_VSA4', 'EState_VSA6', 'PEOE_VSA5', 'HallKierAlpha', 'PEOE_VSA6',
'LabuteASA', 'Chi1v', 'MaxAbsPartialCharge', 'FpDensityMorgan2', 'MinEStateIndex',
'Chi2n', 'VSA_EState3', 'BCUT2D_MWHI', 'NumRadicalElectrons', 'fr_barbitur',
'SMR_VSA3', 'BCUT2D_CHGHI', 'MinAbsPartialCharge', 'Chi4v', 'Kappa1',
'MaxPartialCharge', 'SlogP_VSA7', 'VSA_EState9', 'NumRotatableBonds', 'Ipc',
'MaxAbsEStateIndex', 'BCUT2D_LOGPHI', 'FpDensityMorgan1', 'MinPartialCharge', 'NumBridgeheadAtoms' 
"""

#common descriptors out of lda1 and lda2 top 20
'HallKierAlpha', 'Chi1v', 'Chi4v', 'MaxPartialCharge', 'MaxAbsPartialCharge', 
'SlogP_VSA7', 'MinPartialCharge', 'PEOE_VSA6', 'VSA_EState3', 'EState_VSA6', 
'LabuteASA'

#all descriptors of lda1 and lda2
'HallKierAlpha', 'Chi1v', 'Chi4v', 'MaxPartialCharge', 'MaxAbsPartialCharge', 
'SlogP_VSA7', 'MinPartialCharge', 'PEOE_VSA6', 'VSA_EState3', 'EState_VSA6', 
'LabuteASA', 'PEOE_VSA5', 'NumRotatableBonds', 'NumSaturatedCarbocycles', 'NumHeterocycles',
'NumSaturatedHeterocycles', 'MinAbsPartialCharge', 'FpDensityMorgan1', 'EState_VSA6',
'SlogP_VSA1', 'NumUnspecifiedAtomStereoCenters', 'EState_VSA7', 'VSA_EState9', 'VSA_EState7',
'NumAtomStereoCenters', 'MaxPartialCharge', 'NumAromaticRings', 'Chi1n', 'NumAliphaticRings',
'Chi1', 'NumAmideBonds'

#category wise top 10 using pca:
"""
'NumValenceElectrons', 'HeavyAtomCount', 'LabuteASA', 'ExactMolWt', 'MolWt',
'NumHAcceptors', 'MolMR', 'HeavyAtomMolWt', 'NOCount', 'TPSA',
'MaxAbsEStateIndex', 'MaxEStateIndex', 'BCUT2D_LOGPLOW', 'EState_VSA10', 'BCUT2D_CHGHI',
'BCUT2D_MRLOW', 'MinEStateIndex', 'MinAbsPartialCharge', 'BCUT2D_CHGLO', 'VSA_EState2',
'Chi1v', 'Chi2n', 'Chi3n', 'Chi1', 'Chi0v',
'Chi3v', 'Chi2v', 'Chi0', 'Chi4v', 'Chi4n',
'MolLogP',
'fr_C_O', 'fr_C_O_noCOO', 'Kappa1', 'fr_amide', 'MaxPartialCharge',
'fr_imide', 'fr_ketone', 'fr_urea', 'fr_barbitur', 'fr_ketone_Topliss'
"""

#category wise top 10 using feature selection(univariate):
"""
'BCUT2D_LOGPHI', 'VSA_EState10', 'EState_VSA9', 'VSA_EState6', 'BCUT2D_MWLOW',
'MaxAbsPartialCharge', 'BCUT2D_CHGHI', 'BCUT2D_CHGLO', 'EState_VSA3', 'BCUT2D_MRLOW',
'Chi0v', 'Chi1v', 'NumAromaticCarbocycles', 'Chi2v', 'BertzCT', 
'Chi3v', 'Chi1', 'Chi0', 'Chi4v', 'NumAromaticRings',
'PEOE_VSA6', 'MolMR', 'HeavyAtomMolWt', 'LabuteASA', 'MolWt',
'ExactMolWt', 'FpDensityMorgan1', 'SMR_VSA10', 'HeavyAtomCount', 'SMR_VSA7',
'MolLogP',
'fr_benzene', 'Kappa1', 'fr_halogen', 'RingCount', 'Kappa2',
'MinPartialCharge', 'fr_bicyclic', 'fr_NH2', 'fr_priamide', 'fr_Al_OH_noTert'
"""

#category wise top 10 using feature selection(catboost):
"""
'MinPartialCharge', 'Ipc', 'Kappa1', 'fr_benzene', 'fr_halogen',
'Kappa2', 'MaxPartialCharge', 'RingCount', 'fr_bicyclic', 'fr_Al_OH',
'NumAromaticCarbocycles', 'Chi0v', 'NumHeteroatoms', 'Chi1v', 'NumRotatableBonds',
'BalabanJ', 'Chi3v', 'Chi2v', 'Chi2n', 'Chi4v',
'BCUT2D_LOGPHI', 'MaxAbsPartialCharge', 'VSA_EState6', 'VSA_EState7', 'BCUT2D_MRHI',
'EState_VSA5', 'BCUT2D_MWLOW', 'VSA_EState10', 'BCUT2D_MWHI', 'MaxAbsEStateIndex',
'MolLogP',
'MolMR', 'LabuteASA', 'NOCount', 'PEOE_VSA6', 'SlogP_VSA2',
'ExactMolWt', 'TPSA', 'NumHAcceptors', 'SMR_VSA10', 'HeavyAtomCount' 
"""



#category wise testing on 15 models

# === Part 1: Data Preprocessing ===
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors

# Step 1: Load the data
file_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'
data = pd.read_csv(file_path)

# Step 2: Extract the SMILES column and create a list of SMILES strings
smiles_list = data['smiles'].tolist()

# Step 3: Generate a list of all available descriptor names
descriptor_names = [name for name, func in Descriptors._descList]

# Step 4: Calculate descriptors for each molecule
descriptor_data = []
for smiles in smiles_list:
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        descriptor_values = {name: func(mol) for name, func in Descriptors._descList}
        descriptor_data.append(descriptor_values)
    else:
        descriptor_data.append({name: None for name in descriptor_names})  # Handle invalid molecules

# Step 5: Create descriptor DataFrame
descriptor_df = pd.DataFrame(descriptor_data, columns=descriptor_names)

# Step 6: Define relevant descriptors
relevant_descriptors = [
'Chi1v',
    'PEOE_VSA6',
    'VSA_EState3',
    'EState_VSA6',
    'HallKierAlpha',
    'Chi4v',
    'MaxAbsPartialCharge',
    'PEOE_VSA4',
    'PEOE_VSA5'
 
]

# Step 7: Filter to relevant descriptors
filtered_descriptor_df = descriptor_df[relevant_descriptors]

# Step 8: Combine with original data
final_data = pd.concat([data, filtered_descriptor_df], axis=1)

# Step 9: Keep only numeric values and drop rows with any NaNs in descriptors or target
X = final_data[relevant_descriptors].apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(final_data['log S'], errors='coerce')

X = X.dropna()
y = y.loc[X.index]  # align y

# Step 10: Final train-test split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# === Part 2: Model Training & Evaluation ===
import numpy as np
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, BaggingRegressor, AdaBoostRegressor, HistGradientBoostingRegressor, ExtraTreesRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

# Define models
models = {
    
    #'Linear Regression': LinearRegression(),
    #'Ridge Regression': Ridge(),
    #'Lasso Regression': Lasso(),
    #'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    #'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, random_state=42),
    #'Support Vector Regressor': SVR(),
    #'XGBoost Regressor': XGBRegressor(),
    #'LightGBM Regressor': LGBMRegressor(),
    'CatBoost Regressor': CatBoostRegressor(verbose=0),
    #'Extra Trees Regressor': ExtraTreesRegressor(),
    #'KNN Regressor': KNeighborsRegressor(),
    #'ElasticNet': ElasticNet(),
    #'Bagging Regressor': BaggingRegressor(),
    #'AdaBoost Regressor': AdaBoostRegressor(),
    #'HistGradientBoosting Regressor': HistGradientBoostingRegressor()

}

# Train and evaluate models
results = {}

for name, model in models.items():
    print(f"Training {name}...")
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)

    results[name] = {
        'MSE': mse,
        'RMSE': rmse,
        'R²': r2
    }

    print(f"{name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R²: {r2:.4f}\n")

# Print summary
print("Summary of Model Performance:")
for model_name, metrics in results.items():
    print(f"{model_name} - MSE: {metrics['MSE']:.4f}, RMSE: {metrics['RMSE']:.4f}, R²: {metrics['R²']:.4f}")

# Plot R² scores
plt.figure(figsize=(12, 6))
model_names = list(results.keys())
r2_scores = [metrics['R²'] for metrics in results.values()]
plt.bar(model_names, r2_scores, color='skyblue')
plt.xticks(rotation=45, ha='right')
plt.xlabel('Model')
plt.ylabel('R² Score')
plt.title('Comparison of R² Scores for Different Models')
plt.tight_layout()
plt.show()




#PDP+ICE features. use this with category wise
"""
# === PDP + ICE + Grid Plot for CatBoost Regressor ===
import os
import math
import pandas as pd
import matplotlib.pyplot as plt
from catboost import CatBoostRegressor
from sklearn.inspection import PartialDependenceDisplay

# Create folder for saving individual plots
output_dir = "PDP+ICE_for_21_features"
os.makedirs(output_dir, exist_ok=True)

# Re-train CatBoost (in case it's not already trained)
catboost_model = CatBoostRegressor(verbose=0, random_state=42)
catboost_model.fit(X_train, y_train)

# Set up grid for combining all plots
n_features = len(X.columns)
n_cols = 4  # Customize columns in final grid
n_rows = math.ceil(n_features / n_cols)

fig_grid, axes_grid = plt.subplots(n_rows, n_cols, figsize=(n_cols * 5, n_rows * 4))
axes_grid = axes_grid.flatten()

# Loop through each feature
for idx, feature in enumerate(X.columns):
    # Create individual figure for saving
    fig, ax = plt.subplots(figsize=(6, 4))
    display = PartialDependenceDisplay.from_estimator(
        catboost_model, X, [feature], ax=ax, kind="both",  # PDP + ICE
        subsample=50,  # You can tweak this for smoother ICE lines
        random_state=42
    )
    ax.set_title(f"PDP + ICE for {feature}")
    plt.tight_layout()
    fig.savefig(os.path.join(output_dir, f"{feature}_PDP_ICE.png"))
    plt.close(fig)

    # Also plot into the grid figure
    PartialDependenceDisplay.from_estimator(
        catboost_model, X, [feature], ax=axes_grid[idx], kind="both", subsample=50, random_state=42
    )
    axes_grid[idx].set_title(f"{feature}")

# Hide any unused axes in the grid
for j in range(idx + 1, len(axes_grid)):
    fig_grid.delaxes(axes_grid[j])

plt.tight_layout()
grid_path = os.path.join(output_dir, "PDP_all_grid.png")
plt.savefig(grid_path)
plt.close()

print(f"\n✅ All PDP + ICE plots saved to '{output_dir}' and combined grid saved as 'PDP_all_grid.png'")
"""




#only PDP features. use this with category wise
"""
# === PDP for CatBoost Regressor ===
import os
import pandas as pd
import matplotlib.pyplot as plt
from catboost import CatBoostRegressor
from sklearn.inspection import PartialDependenceDisplay

# Create output folder
output_dir = "PDP_for_21_features"
os.makedirs(output_dir, exist_ok=True)

# Train CatBoost
catboost_model = CatBoostRegressor(verbose=0, random_state=42)
catboost_model.fit(X_train, y_train)

# Generate PDP for each feature
for feature in X.columns:
    fig, ax = plt.subplots(figsize=(6, 4))
    display = PartialDependenceDisplay.from_estimator(
        catboost_model, X, [feature], ax=ax, kind='average'
    )
    ax.set_title(f'PDP for {feature}')
    plt.tight_layout()
    fig_path = os.path.join(output_dir, f"{feature}_PDP.png")
    plt.savefig(fig_path)
    plt.close()

print(f"\n✅ PDP plots saved to folder: '{output_dir}'")
"""





#use this with category wise testing on 15 models to get the SHAP results of whichever 5 10 features you want
"""
# === Part 3: SHAP Analysis on CatBoost ===
import shap

# Step 1: Train CatBoost on the full feature set
cat_model = CatBoostRegressor(verbose=0, random_state=42)
cat_model.fit(X_train, y_train)

# Step 2: Create SHAP explainer and compute SHAP values
explainer = shap.TreeExplainer(cat_model)
shap_values = explainer.shap_values(X_test)

# Step 3: Plot summary of SHAP values (top 20 features)
plt.figure()
shap.summary_plot(shap_values, X_test, max_display=20)

# Optional Step 4: Get top 20 feature names from SHAP
shap_importance = np.abs(shap_values).mean(axis=0)
top_20_indices = np.argsort(shap_importance)[-20:][::-1]
top_20_features = X_train.columns[top_20_indices]

print("\nTop 20 SHAP features:")
for i, feat in enumerate(top_20_features, 1):
    print(f"{i}. {feat}")

# Optional Step 5: Retrain CatBoost on only top 20 features
X_train_top20 = X_train[top_20_features]
X_test_top20 = X_test[top_20_features]

cat_model_top20 = CatBoostRegressor(verbose=0, random_state=42)
cat_model_top20.fit(X_train_top20, y_train)
y_pred_top20 = cat_model_top20.predict(X_test_top20)

mse = mean_squared_error(y_test, y_pred_top20)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred_top20)

print("\nCatBoost (Top 20 SHAP Features) Performance:")
print(f"MSE: {mse:.4f}, RMSE: {rmse:.4f}, R²: {r2:.4f}")
"""



#SHAP analysis of the categories
"""
import pandas as pd
import numpy as np
import shap
import matplotlib.pyplot as plt
from catboost import CatBoostRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score
import os

# ==== Step 0: Define your descriptor categories ====
categories = {
    "Structural Features": [
        'NumAliphaticHeterocycles','NumAliphaticRings','NumAromaticCarbocycles','NumAromaticHeterocycles',
        'NumAromaticRings','NumHeteroatoms','NumRotatableBonds','NumSaturatedHeterocycles','NumSaturatedRings',
        'BalabanJ','BertzCT','Chi0','Chi1','Chi2n','Chi3n','Chi4n','Chi0v','Chi1v','Chi2v','Chi3v','Chi4v'
    ],
    "Electronic Properties": [
        'MaxAbsEStateIndex','MaxEStateIndex','MinAbsEStateIndex','MinEStateIndex','qed','MaxAbsPartialCharge',
        'MinAbsPartialCharge','EState_VSA1','EState_VSA10','EState_VSA11','EState_VSA2','EState_VSA3','EState_VSA4',
        'EState_VSA5','EState_VSA6','EState_VSA7','EState_VSA8','EState_VSA9','VSA_EState1','VSA_EState10',
        'VSA_EState2','VSA_EState3','VSA_EState4','VSA_EState5','VSA_EState6','VSA_EState7','VSA_EState8',
        'VSA_EState9','BCUT2D_CHGHI','BCUT2D_CHGLO','BCUT2D_LOGPHI','BCUT2D_LOGPLOW','BCUT2D_MRHI',
        'BCUT2D_MRLOW','BCUT2D_MWHI','BCUT2D_MWLOW'
    ],
    "Hydrophobicity/Hydrophilicity": ['MolLogP'],
    "Molecular Size and Shape": [
        'MolWt','HeavyAtomMolWt','ExactMolWt','LabuteASA','PEOE_VSA1','PEOE_VSA10','PEOE_VSA11','PEOE_VSA12',
        'PEOE_VSA13','PEOE_VSA14','PEOE_VSA2','PEOE_VSA3','PEOE_VSA4','PEOE_VSA5','PEOE_VSA6','PEOE_VSA7',
        'PEOE_VSA8','PEOE_VSA9','SMR_VSA1','SMR_VSA10','SMR_VSA2','SMR_VSA3','SMR_VSA4','SMR_VSA5','SMR_VSA6',
        'SMR_VSA7','SMR_VSA8','SMR_VSA9','SlogP_VSA1','SlogP_VSA10','SlogP_VSA11','SlogP_VSA12','SlogP_VSA2',
        'SlogP_VSA3','SlogP_VSA4','SlogP_VSA5','SlogP_VSA6','SlogP_VSA7','SlogP_VSA8','SlogP_VSA9',
        'TPSA','HeavyAtomCount','FpDensityMorgan1','FpDensityMorgan2','FpDensityMorgan3','FractionCSP3',
        'MolMR','NHOHCount','NOCount','NumHAcceptors','NumHDonors','NumValenceElectrons'
    ]
}

# Load dataset
df = pd.read_csv("featurized_data_aqsol.csv").dropna()
y = df['log S']

# Log file
summary_log = []

# Directory for SHAP plots
os.makedirs("category_shap_plots", exist_ok=True)

# ==== Step 1: Loop through categories ====
for category_name, features in categories.items():
    print(f"\n🔍 Processing Category: {category_name}")

    # Filter only valid features that exist in dataset
    available_features = [f for f in features if f in df.columns]
    X = df[available_features]

    # Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Scale
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Train CatBoost
    model = CatBoostRegressor(verbose=0, random_state=42)
    model.fit(X_train_scaled, y_train)
    preds = model.predict(X_test_scaled)

    r2 = r2_score(y_test, preds)
    rmse = np.sqrt(mean_squared_error(y_test, preds))

    # SHAP
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_test_scaled)
    mean_abs_shap = np.abs(shap_values).mean(axis=0)

    shap_df = pd.DataFrame({
        "Feature": available_features,
        "MeanAbsSHAP": mean_abs_shap
    }).sort_values(by="MeanAbsSHAP", ascending=False)

    top_features = shap_df.head(5).values.tolist()

    # Log summary
    summary_log.append({
        "Category": category_name,
        "R2": round(r2, 4),
        "RMSE": round(rmse, 4),
        "Top Features": ", ".join([f"{f[0]} ({f[1]:.4f})" for f in top_features])
    })

    # Save plot
    shap.summary_plot(shap_values, X_test_scaled, feature_names=available_features, show=False)
    plt.title(f"SHAP Summary - {category_name}")
    plt.tight_layout()
    safe_category_name = category_name.replace(' ', '_').replace('/', '_')
    plt.savefig(f"category_shap_plots/SHAP_{safe_category_name}.png")
    plt.close()

# ==== Step 2: Save Summary Log ====
summary_df = pd.DataFrame(summary_log)
summary_df.to_csv("category_shap_summary.csv", index=False)
print("\n✅ SHAP summaries saved to 'aqsol_category_shap_summary.csv'")
"""



#applying shap on the top 5 features from each category
"""
import pandas as pd
import shap
import joblib
import matplotlib.pyplot as plt
from catboost import CatBoostRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import os

# === Step 1: Load and preprocess data ===
df = pd.read_csv("featurized_data_aqua.csv").dropna()
X = df.drop(columns=["log S"])
y = df["log S"]

# === Step 2: Define top 5 features from each category ===
top_features = [
    # Structural
    'Chi1v', 'NumHeteroatoms', 'Chi4v', 'NumAromaticRings', 'Chi2n',

    # Electronic
    'EState_VSA6', 'MaxAbsPartialCharge', 'VSA_EState3', 'qed', 'VSA_EState2',

    # Hydrophobicity/Hydrophilicity
    'MolLogP',

    # Molecular Shape & Size
    'PEOE_VSA4', 'PEOE_VSA5', 'LabuteASA', 'HeavyAtomMolWt', 'FpDensityMorgan2'
]

# Filter dataset for only selected features
X_selected = X[top_features]

# === Step 3: Train/Test Split and Scaling ===
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# === Step 4: Train CatBoost Model (CPU only) ===
model = CatBoostRegressor(verbose=0, random_state=42, task_type="CPU")
model.fit(X_train_scaled, y_train)

# === Step 5: SHAP Analysis ===
explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X_test_scaled)

# === Step 6: SHAP Summary Plot ===
plt.figure()
shap.summary_plot(shap_values, X_test_scaled, feature_names=top_features, show=False)
plt.title("SHAP Summary Plot - Top 5 Features from Each Category")
plt.tight_layout()

# Create output directory if not exists
os.makedirs("top_category_shap_plots", exist_ok=True)
plt.savefig("top_category_shap_plots/SHAP_Top_Categories.png", dpi=300)
plt.close()

print("✅ SHAP analysis complete! Plot saved at 'top_category_shap_plots/SHAP_Top_Categories.png'")
"""







#saving the 10 worst predicted molecules from each model
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors

# Load your dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/phys_cure1.csv'  # Update with the correct file path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()  # Replace 'smiles' with the actual column name if different

# Convert SMILES strings to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to a DataFrame with proper descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with the target variable
final_data = pd.concat([features_df, data['log S'].iloc[:len(features_df)]], axis=1)  # Replace 'log S' if your column name differs

# Save the featurized data (optional)
final_data.to_csv('featurized_data_phys.csv', index=False)
print(final_data.head())


import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Load the featurized data
featurized_data = pd.read_csv('featurized_data_phys.csv')

# Drop rows with missing values
featurized_data = featurized_data.dropna()

# Split features and target
X = featurized_data.drop('log S', axis=1)  # Replace 'log S' with your actual target column name
y = featurized_data['log S']

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
import pandas as pd

# Define models
models = {
    'LinearRegression': LinearRegression(),
    'RandomForest': RandomForestRegressor(n_estimators=100, random_state=42),
    'CatBoost': CatBoostRegressor(verbose=0, random_state=42),
    'SVR': SVR()
}

# Prepare a list to store worst predictions
worst_preds = []

# Train, predict, and evaluate each model
for name, model in models.items():
    print(f"\nTraining {name}...")
    model.fit(X_train_scaled, y_train)
    preds = model.predict(X_test_scaled)
    
    # Evaluate
    mse = mean_squared_error(y_test, preds)
    r2 = r2_score(y_test, preds)
    print(f"{name} - MSE: {mse:.4f}, R2: {r2:.4f}")
    
    # Track errors
    errors = np.abs(y_test.values - preds)
    worst_indices = errors.argsort()[-10:][::-1]  # Worst 10
    
    temp_df = pd.DataFrame({
        'model': name,
        'true_logS': y_test.values[worst_indices],
        'predicted_logS': preds[worst_indices],
        'abs_error': errors[worst_indices],
    })
    
    # If you want to include SMILES:
    smiles = data.loc[y_test.index[worst_indices], 'smiles'].values
    temp_df['smiles'] = smiles

    worst_preds.append(temp_df)

# Combine and save worst predictions
final_worst_df = pd.concat(worst_preds, ignore_index=True)
final_worst_df.to_csv('worst_10_predictions_each_model_phys.csv', index=False)
print("\nWorst predictions saved to 'worst_10_predictions_each_model_aqua.csv'")
"""




#testing on anti-cancer
'''
# === Part 1: Data Preprocessing for Train and Test ===
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np

# Define relevant descriptors
relevant_descriptors = [
'Chi1v', 'NumHeteroatoms', 'Chi4v', 'NumAromaticRings', 'Chi2n',
'EState_VSA6', 'MaxAbsPartialCharge', 'VSA_EState3', 'qed', 'VSA_EState2',
'MolLogP',
'PEOE_VSA4', 'PEOE_VSA5', 'LabuteASA', 'HeavyAtomMolWt', 'FpDensityMorgan2',
'MinPartialCharge', 'fr_halogen', 'Kappa1', 'fr_benzene'
]

# Helper function to compute descriptors
def compute_descriptors(df):
    smiles_list = df['smiles'].tolist()
    descriptor_data = []
    for smiles in smiles_list:
        mol = Chem.MolFromSmiles(smiles)
        if mol:
            descriptor_values = {name: func(mol) for name, func in Descriptors._descList}
            descriptor_data.append(descriptor_values)
        else:
            descriptor_data.append({name: None for name, _ in Descriptors._descList})
    descriptor_df = pd.DataFrame(descriptor_data)
    descriptor_df = descriptor_df[relevant_descriptors]
    combined = pd.concat([df, descriptor_df], axis=1)
    X = combined[relevant_descriptors].apply(pd.to_numeric, errors='coerce')
    X = X.replace([np.inf, -np.inf], np.nan)  # Replace infs with NaN
    X = X.dropna()  # Drop rows with NaN
    y = pd.to_numeric(combined['log S'], errors='coerce')
    y = y.loc[X.index]  # Align target values
    return X, y

# Load datasets
train_path = '/content/drive/MyDrive/mol_sol/datasets/aqsol_cure1.csv'
test_path = '/content/drive/MyDrive/mol_sol/datasets/anti_cancer_data.csv'

train_df = pd.read_csv(train_path)
test_df = pd.read_csv(test_path)

# Compute descriptors for train and test
X_train, y_train = compute_descriptors(train_df)
X_test, y_test = compute_descriptors(test_df)

# === Part 2: Model Training & Evaluation ===
import numpy as np
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, BaggingRegressor, AdaBoostRegressor, HistGradientBoostingRegressor, ExtraTreesRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

models = {
    'Linear Regression': LinearRegression(),
    'Ridge Regression': Ridge(),
    'Lasso Regression': Lasso(),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, random_state=42),
    'Support Vector Regressor': SVR(),
    # 'XGBoost Regressor': XGBRegressor(),  # Optional: uncomment if needed
    'LightGBM Regressor': LGBMRegressor(),
    'CatBoost Regressor': CatBoostRegressor(verbose=0),
    'Extra Trees Regressor': ExtraTreesRegressor(),
    'KNN Regressor': KNeighborsRegressor(),
    'ElasticNet': ElasticNet(),
    'Bagging Regressor': BaggingRegressor(),
    'AdaBoost Regressor': AdaBoostRegressor(),
    'HistGradientBoosting Regressor': HistGradientBoostingRegressor()
}

results = {}

for name, model in models.items():
    print(f"Training {name}...")
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)

    results[name] = {'MSE': mse, 'RMSE': rmse, 'R²': r2}

    print(f"{name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R²: {r2:.4f}\n")

# Print summary
print("Summary of Model Performance:")
for model_name, metrics in results.items():
    print(f"{model_name} - MSE: {metrics['MSE']:.4f}, RMSE: {metrics['RMSE']:.4f}, R²: {metrics['R²']:.4f}")

# Plot R² scores
plt.figure(figsize=(12, 6))
model_names = list(results.keys())
r2_scores = [metrics['R²'] for metrics in results.values()]
plt.bar(model_names, r2_scores, color='skyblue')
plt.xticks(rotation=45, ha='right')
plt.xlabel('Model')
plt.ylabel('R² Score')
plt.title('Comparison of R² Scores for Models (Train on Cure1, Test on Cure2)')
plt.tight_layout()
plt.show()

'''



#testing on anti-cancer using bayesian optimization
"""
# === Part 1: Data Preprocessing for Train and Test ===
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors

# Define relevant descriptors
relevant_descriptors = [
    'Chi1v', 'NumHeteroatoms', 'Chi4v', 'NumAromaticRings', 'Chi2n', 
    'EState_VSA6', 'MaxAbsPartialCharge', 'VSA_EState3', 'qed', 'VSA_EState2', 
    'MolLogP', 'PEOE_VSA4', 'PEOE_VSA5', 'LabuteASA', 'HeavyAtomMolWt', 'FpDensityMorgan2'
]

# Helper function to compute descriptors
def compute_descriptors(df):
    smiles_list = df['smiles'].tolist()
    descriptor_data = []
    for smiles in smiles_list:
        mol = Chem.MolFromSmiles(smiles)
        if mol:
            descriptor_values = {name: func(mol) for name, func in Descriptors._descList}
            descriptor_data.append(descriptor_values)
        else:
            descriptor_data.append({name: None for name, _ in Descriptors._descList})
    descriptor_df = pd.DataFrame(descriptor_data)
    descriptor_df = descriptor_df[relevant_descriptors]
    combined = pd.concat([df, descriptor_df], axis=1)
    X = combined[relevant_descriptors].apply(pd.to_numeric, errors='coerce')
    y = pd.to_numeric(combined['log S'], errors='coerce')
    X = X.dropna()
    y = y.loc[X.index]
    return X, y

# Load datasets
train_df = pd.read_csv('/content/drive/MyDrive/mol_sol/datasets/aqsol_cure1.csv')
test_df = pd.read_csv('/content/drive/MyDrive/mol_sol/datasets/anti_cancer_data.csv')

# Compute descriptors
X_train, y_train = compute_descriptors(train_df)
X_test, y_test = compute_descriptors(test_df)

# === Part 2: Models and Bayesian Optimization ===
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score
from skopt import BayesSearchCV
from skopt.space import Real, Integer

from sklearn.linear_model import Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, BaggingRegressor, AdaBoostRegressor, HistGradientBoostingRegressor, ExtraTreesRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor

models_and_spaces = {
    'Ridge Regression': (Ridge(), {
        'alpha': Real(1e-3, 100, prior='log-uniform')
    }),
    'Lasso Regression': (Lasso(), {
        'alpha': Real(1e-3, 100, prior='log-uniform')
    }),
    'ElasticNet': (ElasticNet(), {
        'alpha': Real(1e-3, 100, prior='log-uniform'),
        'l1_ratio': Real(0.0, 1.0)
    }),
    'Random Forest': (RandomForestRegressor(), {
        'n_estimators': Integer(50, 200),
        'max_depth': Integer(5, 30),
        'min_samples_split': Integer(2, 10)
    }),
    'Gradient Boosting': (GradientBoostingRegressor(), {
        'n_estimators': Integer(50, 200),
        'learning_rate': Real(0.01, 0.2),
        'max_depth': Integer(3, 10)
    }),
    'Support Vector Regressor': (SVR(), {
        'C': Real(0.1, 100),
        'epsilon': Real(0.01, 1)
    }),
    'LightGBM Regressor': (LGBMRegressor(), {
        'n_estimators': Integer(50, 200),
        'learning_rate': Real(0.01, 0.2),
        'max_depth': Integer(3, 10)
    }),
    
    'CatBoost Regressor': (CatBoostRegressor(verbose=0), {
        'iterations': Integer(50, 200),
        'learning_rate': Real(0.01, 0.2),
        'depth': Integer(3, 10)
    }),
    'Extra Trees Regressor': (ExtraTreesRegressor(), {
        'n_estimators': Integer(50, 200),
        'max_depth': Integer(5, 30)
    }),
    'KNN Regressor': (KNeighborsRegressor(), {
        'n_neighbors': Integer(2, 20)
    }),
    'Bagging Regressor': (BaggingRegressor(), {
        'n_estimators': Integer(10, 100)
    }),
    'AdaBoost Regressor': (AdaBoostRegressor(), {
        'n_estimators': Integer(50, 200),
        'learning_rate': Real(0.01, 1.0)
    }),
    'HistGradientBoosting Regressor': (HistGradientBoostingRegressor(), {
        'learning_rate': Real(0.01, 0.2),
        'max_iter': Integer(100, 300)
    })
}

results = {}

for name, (model, param_space) in models_and_spaces.items():
    print(f"\nRunning Bayesian Optimization for {name}...")
    opt = BayesSearchCV(
        estimator=model,
        search_spaces=param_space,
        n_iter=20,
        cv=3,
        n_jobs=-1,
        random_state=42,
        scoring='r2'
    )

    opt.fit(X_train, y_train)
    best_model = opt.best_estimator_
    y_pred = best_model.predict(X_test)

    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)

    results[name] = {'MSE': mse, 'RMSE': rmse, 'R²': r2}
    print(f"{name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R²: {r2:.4f}")
    print(f"Best Params: {opt.best_params_}")

# === Part 3: Plot and Summary ===
print("\nSummary of Model Performance:")
for model_name, metrics in results.items():
    print(f"{model_name} - MSE: {metrics['MSE']:.4f}, RMSE: {metrics['RMSE']:.4f}, R²: {metrics['R²']:.4f}")

# Plot R² scores
plt.figure(figsize=(12, 6))
model_names = list(results.keys())
r2_scores = [metrics['R²'] for metrics in results.values()]
plt.bar(model_names, r2_scores, color='skyblue')
plt.xticks(rotation=45, ha='right')
plt.xlabel('Model')
plt.ylabel('R² Score')
plt.title('Comparison of R² Scores (Bayesian Optimization)')
plt.tight_layout()
plt.show()
"""













#lime molecule analysis top molecules
"""
import pandas as pd

data_path = '/content/drive/MyDrive/mol_sol/xai_for_mol_sol/featurized_data_aqua.csv'  # <-- your featurized file
data = pd.read_csv(data_path)

# Step 2: Separate features and target
y = data['log S']
X = data.drop(columns=['log S'])  # Only drop log S, keep all features

print(f"✅ Dataset loaded successfully! Shape of X: {X.shape}, Shape of y: {y.shape}")

# Step 3: Select Top 5 High Solubility Molecules
top25_indices = y.sort_values(ascending=False).head(25).index

X_top25 = X.loc[top25_indices]
y_top25 = y.loc[top25_indices]

# Prepare training set (excluding top 25 molecules)
X_train = X.drop(index=top25_indices)
y_train = y.drop(index=top25_indices)

print(f"✅ Top 25 molecules selected. Training set shape: {X_train.shape}, Top 25 set shape: {X_top25.shape}")

print("Columns in X:")
print(X.columns.tolist())

from sklearn.preprocessing import StandardScaler

# Step 4: Scale the Features for SVR and Linear Regression
scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_top25_scaled = scaler.transform(X_top25)

print("✅ Scaling complete! X_train_scaled shape:", X_train_scaled.shape)

from catboost import CatBoostRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.linear_model import LinearRegression

# Step 5: Initialize models
models = {
    'CatBoost': CatBoostRegressor(verbose=0, random_state=42),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'SVR': SVR(),
    'Linear Regression': LinearRegression()
}

# Step 6: Train the models
trained_models = {}

for name, model in models.items():
    print(f"Training {name}...")
    if name in ['SVR', 'Linear Regression']:
        model.fit(X_train_scaled, y_train)  # Use scaled data
    else:
        model.fit(X_train, y_train)          # Use original data for tree models
    trained_models[name] = model

print("✅ Model training complete!")

# Step 7: Predict the Top 25 molecules
predictions = {}

for name, model in trained_models.items():
    if name in ['SVR', 'Linear Regression']:
        preds = model.predict(X_top25_scaled)  # Use scaled data
    else:
        preds = model.predict(X_top25)          # Use original data
    predictions[name] = preds

print("✅ Predictions complete for Top 25 molecules!")

from lime import lime_tabular
import os
import matplotlib.pyplot as plt

# Step 8: Create LIME explainer
explainer = lime_tabular.LimeTabularExplainer(
    training_data=X_train.values,
    feature_names=X.columns.tolist(),
    mode='regression',
    random_state=42
)



# Create output folders
os.makedirs('new2lime_top25_results', exist_ok=True)
os.makedirs('new2lime_top25_results/plots', exist_ok=True)


# Step 9: Apply LIME explanations and Save plots
lime_results = {}

for idx in X_top25.index:
    instance = X.loc[idx].values
    lime_results[idx] = {}
    for name, model in trained_models.items():
        # Explain instance
        if name in ['SVR', 'Linear Regression']:
           exp = explainer.explain_instance(X_top25_scaled[list(X_top25.index).index(idx)], model.predict, num_features=20)
        else:
           exp = explainer.explain_instance(X_top25.values[list(X_top25.index).index(idx)], model.predict, num_features=20)


        
        lime_results[idx][name] = exp.as_list()
        
        # Save LIME plot
        fig = exp.as_pyplot_figure(label=1)  # regression tasks: label is dummy
        fig.suptitle(f'LIME Explanation\nMolecule {idx} - Model: {name}', fontsize=12)
        plt.tight_layout()
        plt.savefig(f'new2lime_top25_results/plots/Molecule_{idx}_{name}_LIME.png', dpi=300)
        plt.close()

print("✅ LIME explanations and plots saved for Top 25 molecules!")


# Step 10: Create Predicted vs Actual table

# Initialize DataFrame
pred_vs_actual = pd.DataFrame({
    'Molecule_Index': X_top25.index,
    'True_Solubility': y_top25.values
})

# Add model predictions
for name, preds in predictions.items():
    pred_vs_actual[f'{name}_Predicted'] = preds

# Save the table
pred_vs_actual.to_csv('lime_top25_results/pred_vs_actual_top25.csv', index=False)

print("✅ Saved Predicted vs Actual values for Top 25 molecules!")
print(pred_vs_actual)

# Step 11: Save LIME explanations as HTML also

for idx in X_top25.index:
    for name, model in trained_models.items():
        # Same explanation generation
        if name in ['SVR', 'Linear Regression']:
           exp = explainer.explain_instance(X_top25_scaled[list(X_top25.index).index(idx)], model.predict, num_features=20)
        else:
           exp = explainer.explain_instance(X_top25.values[list(X_top25.index).index(idx)], model.predict, num_features=20)


        
        # Save as HTML
        exp.save_to_file(f'lime_top25_results/plots/Molecule_{idx}_{name}_LIME.html')

print("✅ Saved LIME HTML files for all Top 25 molecules and models!")


import matplotlib.pyplot as plt
import numpy as np

# Step 12: Plot True vs Predicted for Top 5 Molecules

model_names = list(predictions.keys())
num_models = len(model_names)

# Setup plot
plt.figure(figsize=(12, 6))

x = np.arange(len(X_top25))  # 25 molecules

# Plot each model's predictions
for i, name in enumerate(model_names):
    preds = predictions[name]
    plt.scatter(x + i*0.05, preds, label=f'{name} Predicted', marker='x')

# Plot True solubility
plt.scatter(x, y_top25.values, color='black', label='True Solubility', marker='o', s=100)

plt.xticks(ticks=x, labels=[f'Mol {i}' for i in X_top25.index])
plt.xlabel('Top 5 Molecules')
plt.ylabel('Solubility (log S)')
plt.title('True vs Predicted Solubility for Top 25 Molecules')
plt.legend()
#plt.grid(True)
plt.tight_layout()

# Save plot
os.makedirs('lime_top25_results/true_vs_predicted_plot', exist_ok=True)
plt.savefig('lime_top25_results/true_vs_predicted_plot/True_vs_Predicted_Top25.png', dpi=300)
plt.show()

print("✅ True vs Predicted plot saved and displayed!")



# Step 13: Save Full LIME Explanations into a CSV

lime_rows = []

for idx, model_dict in lime_results.items():
    for model_name, feature_list in model_dict.items():
        row = {'Molecule_Index': idx, 'Model': model_name}
        for i, (feature, score) in enumerate(feature_list, 1):
            row[f'Feature_{i}'] = feature
            row[f'Score_{i}'] = score
        lime_rows.append(row)

# Create DataFrame
lime_df = pd.DataFrame(lime_rows)

# Save to CSV
lime_df.to_csv('lime_top25_results/top25_molecule_lime_analysis.csv', index=False)

print("✅ Full LIME analysis saved into 'top25_molecule_lime_analysis.csv'!")



import seaborn as sns
import matplotlib.pyplot as plt

# Step 14: Summary Chart of Top Features

# Collect feature appearances
feature_count = {}

for idx, model_dict in lime_results.items():
    for model_name, feature_list in model_dict.items():
        for feature, score in feature_list:
            key = (model_name, feature)
            if key not in feature_count:
                feature_count[key] = 0
            feature_count[key] += 1

# Convert to DataFrame
summary_df = pd.DataFrame([
    {'Model': model, 'Feature': feature, 'Count': count}
    for (model, feature), count in feature_count.items()
])

# Plot
plt.figure(figsize=(14, 8))
sns.barplot(data=summary_df, x='Count', y='Feature', hue='Model')
plt.title('Top Feature Appearance Counts across Models (Top 5 molecules)')
plt.xlabel('Number of Appearances in Top 5 Features')
plt.ylabel('Feature Name')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()

# Save plot
plt.savefig('lime_top5_results/summary_feature_appearance.png', dpi=300)
plt.show()

print("✅ Summary chart of top features saved!")


import numpy as np

# Step 15: Feature Importance Heatmap (Model by Model)

# Go through each model
for model_name in trained_models.keys():
    # Build matrix for this model
    heatmap_data = []
    molecule_ids = []
    features_seen = set()
    
    for idx in X_top5.index:
        if model_name not in lime_results[idx]:
            continue
        feature_list = lime_results[idx][model_name]
        molecule_ids.append(idx)
        feature_score_dict = {feature: score for feature, score in feature_list}
        features_seen.update(feature_score_dict.keys())
        heatmap_data.append(feature_score_dict)
    
    # Build final DataFrame
    all_features = sorted(list(features_seen))
    heatmap_df = pd.DataFrame(columns=all_features)

    for i, molecule_scores in enumerate(heatmap_data):
        row = []
        for feat in all_features:
            row.append(molecule_scores.get(feat, np.nan))
        heatmap_df.loc[molecule_ids[i]] = row

    # Plot heatmap
    plt.figure(figsize=(14, 8))
    sns.heatmap(heatmap_df, annot=True, cmap='coolwarm', linewidths=0.5, linecolor='gray', fmt=".2f")
    plt.title(f'LIME Feature Importance Heatmap - {model_name}')
    plt.xlabel('Feature')
    plt.ylabel('Molecule Index')
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    
    # Save the heatmap
    os.makedirs('lime_top5_results/heatmaps', exist_ok=True)
    plt.savefig(f'lime_top5_results/heatmaps/LIME_Heatmap_{model_name}.png', dpi=300)
    plt.close()

print("✅ LIME Heatmaps saved for all models!")
"""



# === LIME Analysis with 20 Descriptors on Top 25 Molecules ===
"""
import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import Descriptors
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.linear_model import LinearRegression
from lime import lime_tabular
import os
import matplotlib.pyplot as plt

# === Step 1: Load and Featurize Dataset ===
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'
data = pd.read_csv(data_path)

smiles_list = data['smiles'].tolist()
descriptor_names = [name for name, func in Descriptors._descList]

descriptor_data = []
for smiles in smiles_list:
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        descriptor_values = {name: func(mol) for name, func in Descriptors._descList}
        descriptor_data.append(descriptor_values)
    else:
        descriptor_data.append({name: None for name in descriptor_names})

descriptor_df = pd.DataFrame(descriptor_data, columns=descriptor_names)

# === Step 2: Use only selected 20 descriptors ===
selected_descriptors = [
    'Chi1v', 'NumHeteroatoms', 'Chi4v', 'NumAromaticRings', 'Chi2n',
    'EState_VSA6', 'MaxAbsPartialCharge', 'VSA_EState3', 'qed', 'VSA_EState2',
    'MolLogP', 'PEOE_VSA4', 'PEOE_VSA5', 'LabuteASA', 'HeavyAtomMolWt',
    'FpDensityMorgan2', 'MinPartialCharge', 'fr_halogen', 'Kappa1', 'fr_benzene', 'NumValenceElectrons'
]

X = descriptor_df[selected_descriptors].apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(data['log S'], errors='coerce')

# Drop rows with NaNs
X = X.dropna()
y = y.loc[X.index]

# === Step 3: Identify Top 25 Most Soluble Molecules ===
top25_indices = y.sort_values(ascending=False).head(25).index
X_top25 = X.loc[top25_indices]
y_top25 = y.loc[top25_indices]

X_train = X.drop(index=top25_indices)
y_train = y.drop(index=top25_indices)

# === Step 4: Scale for SVR and Linear Regression ===
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_top25_scaled = scaler.transform(X_top25)

# === Step 5: Initialize Models ===
models = {
    'CatBoost': CatBoostRegressor(verbose=0, random_state=42),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'SVR': SVR(),
    'Linear Regression': LinearRegression()
}

trained_models = {}
predictions = {}
for name, model in models.items():
    if name in ['SVR', 'Linear Regression']:
        model.fit(X_train_scaled, y_train)
        preds = model.predict(X_top25_scaled)
    else:
        model.fit(X_train, y_train)
        preds = model.predict(X_top25)
    trained_models[name] = model
    predictions[name] = preds


import os
import numpy as np
import matplotlib.pyplot as plt
from lime import lime_tabular

# Create output directory
output_dir = 'lime_top25_cleaned'
os.makedirs(output_dir, exist_ok=True)

# Use LIME explainer on unscaled training data
explainer = lime_tabular.LimeTabularExplainer(
    training_data=X_train.values,
    feature_names=X_train.columns.tolist(),
    mode='regression',
    random_state=42
)

# Mapping for scaled vs. unscaled instance
def get_instance_for_model(model_name, idx):
    if model_name in ['SVR', 'Linear Regression']:
        return X_top25_scaled[X_top25.index.get_loc(idx)]
    else:
        return X_top25.loc[idx].values

# Plotting function
def plot_lime_explanation(exp, idx, model_name):
    fig, ax = plt.subplots(figsize=(8, 6))

    exp_list = exp.as_list()
    features = [f for f, _ in exp_list]
    weights = [w for _, w in exp_list]

    y_pos = np.arange(len(features))
    colors = ['green' if w > 0 else 'red' for w in weights]

    bars = ax.barh(y_pos, weights, color=colors)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(features, fontsize=9)
    ax.invert_yaxis()
    ax.set_xlabel('Contribution to Prediction', fontsize=10)
    ax.set_title(f'LIME Explanation\nMolecule {idx} - Model: {model_name}', fontsize=12)

    # Smart axis limit for better visual balance
    max_abs = max(abs(w) for w in weights)
    ax.set_xlim(-max_abs * 1.2, max_abs * 1.2)

    # Annotate bars
    #for i, bar in enumerate(bars):
     #   width = bar.get_width()
     #   ha = 'left' if width > 0 else 'right'
      #  offset = 0.002 if width > 0 else -0.002
       # ax.text(width + offset, bar.get_y() + bar.get_height()/2,
        #        f'{width:.3f}', ha=ha, va='center', fontsize=8, color='blue')

    ax.grid(True, axis='x', linestyle='--', alpha=0.6)
    plt.tight_layout()
    plt.savefig(f'{output_dir}/Molecule_{idx}_{model_name}_LIME.png', dpi=300)
    plt.close()

# Run for each of the top 25 molecules and models
for idx in X_top25.index:
    for model_name, model in trained_models.items():
        instance = get_instance_for_model(model_name, idx)
        explanation = explainer.explain_instance(instance, model.predict, num_features=21)
        plot_lime_explanation(explanation, idx, model_name)



# === Step 6: LIME Explainer ===
explainer = lime_tabular.LimeTabularExplainer(
    training_data=X_train.values,
    feature_names=selected_descriptors,
    mode='regression',
    random_state=42
)

os.makedirs('lime_top25_features20', exist_ok=True)

import matplotlib.pyplot as plt

# === Step 7: Generate Cleaner LIME Plots ===
for idx in X_top25.index:
    for name, model in trained_models.items():
        # Select correct input data (scaled or unscaled)
        if name in ['SVR', 'Linear Regression']:
            instance_values = X_top25_scaled[X_top25.index.get_loc(idx)]
        else:
            instance_values = X_top25.loc[idx].values

        # Generate LIME explanation
        exp = explainer.explain_instance(instance_values, model.predict, num_features=21)

        # --- Plot LIME explanation ---
        fig = exp.as_pyplot_figure(label=1)
        ax = fig.axes[0]  # use the first axis safely

        # Annotate bars with values in a tidy way
        for p in ax.patches:
            width = p.get_width()
            if width != 0:
                ha = 'left' if width > 0 else 'right'
                offset = 0.002 if width > 0 else -0.002
                ax.annotate(f'{width:.3f}',
                            (width + offset, p.get_y() + p.get_height() / 2),
                            ha=ha, va='center',
                            fontsize=7, color='blue')

        # Dynamically set nice x-axis limit
        max_width = max(abs(p.get_width()) for p in ax.patches)
        ax.set_xlim(left=0, right=max_width * 1.1)  # 10% extra space


        # Title and layout
        fig.suptitle(f'LIME Explanation\nMolecule {idx} - Model: {name}', fontsize=12)
        plt.tight_layout(pad=2.0)
        plt.savefig(f'lime_top25_features20/Molecule_{idx}_{name}_LIME.png', dpi=300)
        plt.close()






# === Step 8: Plot True vs Predicted for Top 25 (Improved Scatter Plot) ===
model_names = list(predictions.keys())
num_models = len(model_names)

plt.figure(figsize=(12, 6))
x = np.arange(len(X_top25))

# Plot model predictions
for i, name in enumerate(model_names):
    preds = predictions[name]
    plt.scatter(x + i * 0.05, preds, label=f'{name} Predicted', marker='x')

# Plot true solubility
plt.scatter(x, y_top25.values, color='black', label='True Solubility', marker='o', s=100)

plt.xticks(ticks=x, labels=[f'Mol {i}' for i in X_top25.index], rotation=90)
plt.xlabel('Top 25 Molecules')
plt.ylabel('Solubility (log S)')
plt.title('True vs Predicted Solubility for Top 25 Molecules')
plt.legend()
plt.tight_layout()
plt.savefig('lime_top25_features20/true_vs_predicted_top25.png', dpi=300)
plt.show()
"""

"""
import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import Descriptors
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.linear_model import LinearRegression
import shap
import matplotlib.pyplot as plt
import os

# === Step 1: Load and Featurize Dataset ===
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'
data = pd.read_csv(data_path)

smiles_list = data['smiles'].tolist()
descriptor_names = [name for name, func in Descriptors._descList]

descriptor_data = []
for smiles in smiles_list:
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        descriptor_values = {name: func(mol) for name, func in Descriptors._descList}
        descriptor_data.append(descriptor_values)
    else:
        descriptor_data.append({name: None for name in descriptor_names})

descriptor_df = pd.DataFrame(descriptor_data, columns=descriptor_names)

# === Step 2: Use only selected 21 descriptors ===
selected_descriptors = [
    'Chi1v', 'NumHeteroatoms', 'Chi4v', 'NumAromaticRings', 'Chi2n',
    'EState_VSA6', 'MaxAbsPartialCharge', 'VSA_EState3', 'qed', 'VSA_EState2',
    'MolLogP', 'PEOE_VSA4', 'PEOE_VSA5', 'LabuteASA', 'HeavyAtomMolWt',
    'FpDensityMorgan2', 'MinPartialCharge', 'fr_halogen', 'Kappa1', 'fr_benzene', 'NumValenceElectrons'
]

X = descriptor_df[selected_descriptors].apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(data['log S'], errors='coerce')

# Drop rows with NaNs
X = X.dropna()
y = y.loc[X.index]

# === Step 3: Train-test split and scaling ===
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# === Step 4: Define and train models ===
models = {
    'CatBoost': CatBoostRegressor(verbose=0, random_state=42),
    'Linear Regression': LinearRegression(),
    'SVR': SVR(),
    'Random Forest': RandomForestRegressor(random_state=42)
}

# === Step 5: Create directory to save SHAP figures ===
output_dir = "shap_figures_21_features"
os.makedirs(output_dir, exist_ok=True)

# === Step 6: SHAP plotting function ===
def plot_shap(model_name, model, X_train, X_test):
    print(f"Explaining model: {model_name}")

    # Choose appropriate SHAP explainer
    if model_name in ['CatBoost', 'Random Forest']:
        explainer = shap.TreeExplainer(model)
    elif model_name in ['Linear Regression', 'SVR']:
        explainer = shap.KernelExplainer(model.predict, shap.kmeans(X_train, 10))
    else:
        raise ValueError("Unsupported model")

    # Compute SHAP values
    shap_values = explainer.shap_values(X_test)

    # SHAP Bar Plot
    shap.summary_plot(shap_values, X_test, feature_names=X.columns, plot_type="bar", show=False)
    plt.gcf().tight_layout()
    bar_path = os.path.join(output_dir, f"{model_name}_SHAP_bar.png")
    plt.savefig(bar_path, bbox_inches='tight')
    plt.close()

    # SHAP Beeswarm Plot
    shap.summary_plot(shap_values, X_test, feature_names=X.columns, show=False)
    plt.gcf().tight_layout()
    beeswarm_path = os.path.join(output_dir, f"{model_name}_SHAP_beeswarm.png")
    plt.savefig(beeswarm_path, bbox_inches='tight')
    plt.close()

# === Step 7: Train and explain each model ===
for model_name, model in models.items():
    print(f"\nTraining model: {model_name}")
    if model_name in ['Linear Regression', 'SVR']:
        model.fit(X_train_scaled, y_train)
        plot_shap(model_name, model, X_train_scaled, X_test_scaled)
    else:
        model.fit(X_train, y_train)
        plot_shap(model_name, model, X_train, X_test)

print(f"\nAll SHAP plots saved to: {output_dir}")
"""



#21 descriptors on various solubility classes
"""
import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import Descriptors
from catboost import CatBoostRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import joblib

# ========== Step 1: Load Data ==========
file_path = '/content/drive/MyDrive/mol_sol/datasets/aqsol_cure1.csv'
data = pd.read_csv(file_path)
smiles_list = data['smiles'].tolist()

# ========== Step 2: Define Relevant Descriptors ==========
relevant_descriptors = [
    'Chi1v', 'NumHeteroatoms', 'Chi4v', 'NumAromaticRings', 'Chi2n',
    'EState_VSA6', 'MaxAbsPartialCharge', 'VSA_EState3', 'qed', 'VSA_EState2', 
    'MolLogP', 'PEOE_VSA4', 'PEOE_VSA5', 'LabuteASA', 'HeavyAtomMolWt',
    'FpDensityMorgan2', 'MinPartialCharge', 'fr_halogen', 'Kappa1', 'fr_benzene'
]

# ========== Step 3: Compute Selected Descriptors ==========
descriptor_data = []
valid_indices = []

for idx, smiles in enumerate(smiles_list):
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        values = {name: func(mol) for name, func in Descriptors._descList if name in relevant_descriptors}
        descriptor_data.append(values)
        valid_indices.append(idx)

# Keep only valid rows
descriptor_df = pd.DataFrame(descriptor_data)
filtered_data = data.loc[valid_indices].reset_index(drop=True)
descriptor_df = descriptor_df.reset_index(drop=True)

# ========== Step 4: Merge Features and Target ==========
final_df = pd.concat([filtered_data[['smiles', 'log S']], descriptor_df], axis=1)

# ========== Step 5: Define Solubility Classes ==========
low_thresh = final_df['log S'].quantile(0.33)
high_thresh = final_df['log S'].quantile(0.66)

def assign_class(logs):
    if logs <= low_thresh:
        return 'low'
    elif logs <= high_thresh:
        return 'medium'
    else:
        return 'high'

final_df['solubility_class'] = final_df['log S'].apply(assign_class)

# ========== Step 6: Train and Evaluate CatBoost per Cluster ==========
feature_cols = relevant_descriptors
results = []

def train_and_evaluate(cluster_label):
    print(f"\n🔍 Processing '{cluster_label.upper()}' cluster")

    # Filter by cluster
    cluster_df = final_df[final_df['solubility_class'] == cluster_label]
    X = cluster_df[feature_cols]
    y = cluster_df['log S']

    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train CatBoost
    model = CatBoostRegressor(verbose=0, random_state=42)
    model.fit(X_train, y_train)

    # Save model
    joblib.dump(model, f'catboost_selected_{cluster_label}.pkl')

    # Evaluate
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)

    print(f"📈 Metrics for {cluster_label.upper()}: MSE={mse:.4f}, RMSE={rmse:.4f}, R²={r2:.4f}")
    results.append({
        'Cluster': cluster_label,
        'MSE': mse,
        'RMSE': rmse,
        'R2': r2
    })

# Run for all clusters
for label in ['low', 'medium', 'high']:
    train_and_evaluate(label)

# ========== Step 7: Summary ==========
print("\n📊 Summary of Results:")
results_df = pd.DataFrame(results)
print(results_df)
"""




#lime for bottom 25 molecules
"""
import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import Descriptors
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.linear_model import LinearRegression
from lime import lime_tabular
import matplotlib.pyplot as plt
import os

# === Step 1: Load and Featurize Dataset ===
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'
data = pd.read_csv(data_path)

smiles_list = data['smiles'].tolist()
descriptor_names = [name for name, func in Descriptors._descList]

descriptor_data = []
for smiles in smiles_list:
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        descriptor_values = {name: func(mol) for name, func in Descriptors._descList}
        descriptor_data.append(descriptor_values)
    else:
        descriptor_data.append({name: None for name in descriptor_names})

descriptor_df = pd.DataFrame(descriptor_data, columns=descriptor_names)

# === Step 2: Use only selected 20 descriptors ===
selected_descriptors = [
    'Chi1v', 'NumHeteroatoms', 'Chi4v', 'NumAromaticRings', 'Chi2n',
    'EState_VSA6', 'MaxAbsPartialCharge', 'VSA_EState3', 'qed', 'VSA_EState2',
    'MolLogP', 'PEOE_VSA4', 'PEOE_VSA5', 'LabuteASA', 'HeavyAtomMolWt',
    'FpDensityMorgan2', 'MinPartialCharge', 'fr_halogen', 'Kappa1', 'fr_benzene', 'NumValenceElectrons'
]

X = descriptor_df[selected_descriptors].apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(data['log S'], errors='coerce')

# Drop rows with NaNs
X = X.dropna()
y = y.loc[X.index]

# === Step 3: Identify Top 25 Most Soluble Molecules ===
bottom25_indices = y.sort_values(ascending=True).head(25).index
X_bottom25 = X.loc[bottom25_indices]
y_bottom25 = y.loc[bottom25_indices]

X_train = X.drop(index=bottom25_indices)
y_train = y.drop(index=bottom25_indices)

# === Step 4: Scale for SVR and Linear Regression ===
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_bottom25_scaled = scaler.transform(X_bottom25)

# === Step 5: Initialize Models ===
models = {
    'CatBoost': CatBoostRegressor(verbose=0, random_state=42),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'SVR': SVR(),
    'Linear Regression': LinearRegression()
}

trained_models = {}
predictions = {}
for name, model in models.items():
    if name in ['SVR', 'Linear Regression']:
        model.fit(X_train_scaled, y_train)
        preds = model.predict(X_bottom25_scaled)
    else:
        model.fit(X_train, y_train)
        preds = model.predict(X_bottom25)
    trained_models[name] = model
    predictions[name] = preds

# === Step 6: LIME Explainer ===
output_dir = 'llllime_bottom25_features20'
os.makedirs(output_dir, exist_ok=True)

explainer = lime_tabular.LimeTabularExplainer(
    training_data=X_train.values,
    feature_names=selected_descriptors,
    mode='regression',
    random_state=42
)



import matplotlib.pyplot as plt

# === Step 7: Generate Cleaner LIME Plots with Custom Style ===

def plot_lime_explanation(exp, idx, model_name):
    fig, ax = plt.subplots(figsize=(8, 6))

    exp_list = exp.as_list()
    features = [f for f, _ in exp_list]
    weights = [w for _, w in exp_list]

    y_pos = np.arange(len(features))
    colors = ['green' if w > 0 else 'red' for w in weights]

    bars = ax.barh(y_pos, weights, color=colors)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(features, fontsize=9)
    ax.invert_yaxis()
    ax.set_xlabel('Contribution to Prediction', fontsize=10)
    ax.set_title(f'LIME Explanation\nMolecule {idx} - Model: {model_name}', fontsize=12)

    # Smart axis limit for better visual balance
    max_abs = max(abs(w) for w in weights)
    ax.set_xlim(-max_abs * 1.2, max_abs * 1.2)

    # Annotate bars
    #for i, bar in enumerate(bars):
     #   width = bar.get_width()
      #  ha = 'left' if width > 0 else 'right'
       # offset = 0.002 if width > 0 else -0.002
        #ax.text(width + offset, bar.get_y() + bar.get_height()/2,
         #       f'{width:.3f}', ha=ha, va='center', fontsize=8, color='blue')

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f'Molecule_{idx}_{model_name}_LIME.png'), dpi=300)
    plt.close()

# Generate LIME explanations and use the custom plotting function
for idx in X_bottom25.index:
    for name, model in trained_models.items():
        # Select correct input data (scaled or unscaled)
        if name in ['SVR', 'Linear Regression']:
            instance_values = X_bottom25_scaled[X_bottom25.index.get_loc(idx)]
        else:
            instance_values = X_bottom25.loc[idx].values

        # Generate LIME explanation
        exp = explainer.explain_instance(instance_values, model.predict, num_features=21)

        # Plot using the clean function
        plot_lime_explanation(exp, idx, name)


# === Step 8: Plot True vs Predicted for Top 25 (Improved Scatter Plot) ===
model_names = list(predictions.keys())
num_models = len(model_names)

plt.figure(figsize=(12, 6))
x = np.arange(len(X_bottom25))

# Plot model predictions
for i, name in enumerate(model_names):
    preds = predictions[name]
    plt.scatter(x + i * 0.05, preds, label=f'{name} Predicted', marker='x')

# Plot true solubility
plt.scatter(x, y_bottom25.values, color='black', label='True Solubility', marker='o', s=100)

plt.xticks(ticks=x, labels=[f'Mol {i}' for i in X_bottom25.index], rotation=90)
plt.xlabel('25 least Soluble Molecules')
plt.ylabel('Solubility (log S)')
plt.title('True vs Predicted Solubility for 25 least Soluble Molecules')
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(output_dir, 'true_vs_predicted_bottom25.png'), dpi=300)
plt.show()
"""


#pca
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors

# Load your dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'  # Update with the correct file path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()  # Replace 'smiles' with the actual column name if different

# Convert SMILES strings to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to a DataFrame with proper descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with the target variable
final_data = pd.concat([features_df, data['log S'].iloc[:len(features_df)]], axis=1)  # Replace 'log S' if your column name differs

# Save the featurized data (optional)
final_data.to_csv('featurized_data_aqua.csv', index=False)
print(final_data.head())

import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Load the featurized data
featurized_data = pd.read_csv('featurized_data_aqua.csv')

# Drop rows with missing values
featurized_data = featurized_data.dropna()

# Split features and target
X = featurized_data.drop('log S', axis=1)  # Replace 'log S' with your actual target column name
y = featurized_data['log S']

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
import matplotlib.pyplot as plt
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# 1. Apply PCA
pca = PCA(n_components=0.95)  # keep 95% of variance
X_train_pca = pca.fit_transform(X_train_scaled)
X_test_pca = pca.transform(X_test_scaled)

print(f"Original feature count: {X_train_scaled.shape[1]}")
print(f"Reduced feature count (95% variance): {X_train_pca.shape[1]}")

# 2. Plot explained variance
plt.figure(figsize=(10, 5))
plt.plot(np.cumsum(pca.explained_variance_ratio_), marker='o')
plt.xlabel('Number of Principal Components')
plt.ylabel('Cumulative Explained Variance')
plt.title('Explained Variance by PCA Components')
plt.grid(True)
plt.tight_layout()
plt.savefig("pca_variance_explained.png")
plt.show()

# 3. Train models on PCA-transformed data
models = {
    "CatBoost": CatBoostRegressor(verbose=0),
    "LinearRegression": LinearRegression(),
    "RandomForest": RandomForestRegressor(),
    "SVR": SVR()
}

results = {}
for name, model in models.items():
    model.fit(X_train_pca, y_train)
    y_pred = model.predict(X_test_pca)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    results[name] = {"MSE": mse, "RMSE": rmse, "R2": r2}
    print(f"{name} -> MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2: {r2:.4f}")


import numpy as np
import pandas as pd

# Load descriptor names
descriptor_names = X.columns.tolist()

# Get PCA components (loadings)
loadings = pd.DataFrame(
    data=pca.components_.T,
    columns=[f'PC{i+1}' for i in range(pca.n_components_)],
    index=descriptor_names
)

# Get top contributing features for first 5 PCs
top_features_per_pc = {}
num_top = 10  # Top 10 contributors per component

for pc in loadings.columns[:5]:  # First 5 components
    top_features = loadings[pc].abs().sort_values(ascending=False).head(num_top)
    top_features_per_pc[pc] = top_features

# Combine into one DataFrame for easy viewing
top_features_df = pd.concat(top_features_per_pc, axis=1)
top_features_df.to_csv('pca_top_feature_contributions.csv')

print("Top contributing features to first 10 principal components:")
print(top_features_df)


import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(14, 8))
sns.heatmap(
    top_features_df,
    annot=True,
    cmap="coolwarm",
    center=0,
    fmt=".2f"
)
plt.tight_layout()
plt.savefig("pca_feature_contribution_heatmap.png")
plt.show()


# Sum of absolute loadings across all retained PCs (here 5 PCs)
descriptor_influence = loadings.iloc[:, :5].abs().sum(axis=1)

# Sort descriptors by total contribution
top_overall_descriptors = descriptor_influence.sort_values(ascending=False).head(30)

# Save to CSV
top_overall_descriptors.to_csv("top_overall_influential_descriptors.csv", header=["Total_Influence"])

print("Top 30 Overall Influential Descriptors (PCA Loadings Sum):")
print(top_overall_descriptors)


import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV file
top_features_df = pd.read_csv('pca_top_feature_contributions.csv', index_col=0)

# Sum the absolute values of contributions across the first 5 principal components
overall_influence = top_features_df.iloc[:, :5].abs().sum(axis=1)

# Get top 30 overall influential descriptors
top_overall_descriptors = overall_influence.sort_values(ascending=False).head(30)

# Plot
plt.figure(figsize=(12, 8))
top_overall_descriptors.plot(kind='barh', color='skyblue')
plt.xlabel("Total Contribution Across First 5 PCs")
plt.ylabel("Descriptor")
plt.title("Top 30 Overall Influential Descriptors (PCA)")
plt.gca().invert_yaxis()
plt.tight_layout()
plt.savefig("pca_top30_overall_influential_descriptors.png")
plt.show()
"""


#feature selection(univariate):
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors

# Load your dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'  # Update with the correct file path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()  # Replace 'smiles' with the actual column name if different

# Convert SMILES strings to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to a DataFrame with proper descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with the target variable
final_data = pd.concat([features_df, data['log S'].iloc[:len(features_df)]], axis=1)  # Replace 'log S' if your column name differs

# Save the featurized data (optional)
final_data.to_csv('featurized_data_aqua.csv', index=False)
print(final_data.head())

import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Load the featurized data
featurized_data = pd.read_csv('featurized_data_aqua.csv')

# Drop rows with missing values
featurized_data = featurized_data.dropna()

# Split features and target
X = featurized_data.drop('log S', axis=1)  # Replace 'log S' with your actual target column name
y = featurized_data['log S']

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

from sklearn.feature_selection import SelectKBest, f_regression

# Apply univariate feature selection
k = 30  # You can change this to select more/fewer features
selector = SelectKBest(score_func=f_regression, k=k)
X_train_selected = selector.fit_transform(X_train_scaled, y_train)
X_test_selected = selector.transform(X_test_scaled)

# Get the selected feature names
mask = selector.get_support()
selected_feature_names = X.columns[mask]
print("Top", k, "selected features based on univariate selection:")
print(selected_feature_names.tolist())

import matplotlib.pyplot as plt
import numpy as np

# Fit the selector on the full training data
selector = SelectKBest(score_func=f_regression, k='all')
selector.fit(X_train_scaled, y_train)

# Get F-scores and feature names
f_scores = selector.scores_
feature_names = X.columns

# Create a DataFrame of features and their scores
f_score_df = pd.DataFrame({
    'Feature': feature_names,
    'F_score': f_scores
}).sort_values(by='F_score', ascending=False)

# Plot top 30 features
top_k = 30
plt.figure(figsize=(12, 8))
plt.barh(f_score_df['Feature'].iloc[:top_k][::-1], f_score_df['F_score'].iloc[:top_k][::-1], color='darkblue')
plt.xlabel('F-score')
plt.tight_layout()
plt.savefig("univariate_top30_features_fscore.png")
plt.show()
"""

#feature selection(model based)
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors

# Load your dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'  # Update with the correct file path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()  # Replace 'smiles' with the actual column name if different

# Convert SMILES strings to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to a DataFrame with proper descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with the target variable
final_data = pd.concat([features_df, data['log S'].iloc[:len(features_df)]], axis=1)  # Replace 'log S' if your column name differs

# Save the featurized data (optional)
final_data.to_csv('featurized_data_aqua.csv', index=False)
print(final_data.head())

import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Load the featurized data
featurized_data = pd.read_csv('featurized_data_aqua.csv')

# Drop rows with missing values
featurized_data = featurized_data.dropna()

# Split features and target
X = featurized_data.drop('log S', axis=1)  # Replace 'log S' with your actual target column name
y = featurized_data['log S']

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

from catboost import CatBoostRegressor

# Train CatBoostRegressor
model = CatBoostRegressor(verbose=0, random_state=42)
model.fit(X_train_scaled, y_train)

# Get feature importances
importances = model.get_feature_importance()
feature_names = X.columns

# Create a DataFrame of feature importances
importance_df = pd.DataFrame({
    'Feature': feature_names,
    'Importance': importances
}).sort_values(by='Importance', ascending=False)


import matplotlib.pyplot as plt

top_k = 30
plt.figure(figsize=(12, 8))
plt.barh(importance_df['Feature'].iloc[:top_k][::-1], importance_df['Importance'].iloc[:top_k][::-1], color='blue')
plt.xlabel('Feature Importance')
plt.tight_layout()
plt.savefig("catboost_top30_features_importance.png")
plt.show()

from sklearn.ensemble import RandomForestRegressor

rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
rf_model.fit(X_train_scaled, y_train)

# Get feature importances
rf_importances = rf_model.feature_importances_
rf_importance_df = pd.DataFrame({
    'Feature': X.columns,
    'Importance': rf_importances
}).sort_values(by='Importance', ascending=False)

# Plot top 30
plt.figure(figsize=(12, 8))
plt.barh(rf_importance_df['Feature'].iloc[:30][::-1], rf_importance_df['Importance'].iloc[:30][::-1], color='darkblue')
plt.xlabel('Feature Importance')
plt.tight_layout()
plt.savefig("rf_top30_features_importance.png")
plt.show()

from sklearn.linear_model import LinearRegression

lr_model = LinearRegression()
lr_model.fit(X_train_scaled, y_train)

# Get absolute coefficient magnitudes
lr_coeffs = np.abs(lr_model.coef_)
lr_importance_df = pd.DataFrame({
    'Feature': X.columns,
    'Importance': lr_coeffs
}).sort_values(by='Importance', ascending=False)

# Plot top 30
plt.figure(figsize=(12, 8))
plt.barh(lr_importance_df['Feature'].iloc[:30][::-1], lr_importance_df['Importance'].iloc[:30][::-1], color='darkblue')
plt.xlabel('Absolute Coefficient')
plt.tight_layout()
plt.savefig("lr_top30_features_importance.png")
plt.show()

from sklearn.svm import SVR

svr_model = SVR(kernel='linear')  # Must use linear kernel for interpretability
svr_model.fit(X_train_scaled, y_train)

# Get absolute coefficients
svr_coeffs = np.abs(svr_model.coef_).flatten()
svr_importance_df = pd.DataFrame({
    'Feature': X.columns,
    'Importance': svr_coeffs
}).sort_values(by='Importance', ascending=False)

# Plot top 30
plt.figure(figsize=(12, 8))
plt.barh(svr_importance_df['Feature'].iloc[:30][::-1], svr_importance_df['Importance'].iloc[:30][::-1], color='darkblue')
plt.xlabel('Absolute Coefficient')
plt.tight_layout()
plt.savefig("svr_top30_features_importance.png")
plt.show()
"""

#lda
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors

# Load your dataset
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'  # Update with the correct file path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()  # Replace 'smiles' with the actual column name if different

# Convert SMILES strings to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Retrieve descriptor names from RDKit
descriptor_names = [desc_name for desc_name, _ in Descriptors.descList]

# Convert features to a DataFrame with proper descriptor names
features_df = pd.DataFrame(features, columns=descriptor_names)

# Combine features with the target variable
final_data = pd.concat([features_df, data['log S'].iloc[:len(features_df)]], axis=1)  # Replace 'log S' if your column name differs

# Save the featurized data (optional)
final_data.to_csv('featurized_data_aqua.csv', index=False)
print(final_data.head())

import pandas as pd
import deepchem as dc
from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Load the featurized data
featurized_data = pd.read_csv('featurized_data_aqua.csv')

# Drop rows with missing values
featurized_data = featurized_data.dropna()

# Split features and target
X = featurized_data.drop('log S', axis=1)  # Replace 'log S' with your actual target column name
y = featurized_data['log S']

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
import matplotlib.pyplot as plt

# Bin only y_train, not full y
y_train_binned = pd.qcut(y_train, q=3, labels=["Low", "Medium", "High"])

# Apply LDA on training data
lda = LDA(n_components=2)
X_lda = lda.fit_transform(X_train_scaled, y_train_binned)

# Plot the result
import matplotlib.pyplot as plt

plt.figure(figsize=(10, 6))
colors = {'Low': 'darkblue', 'Medium': 'orange', 'High': 'green'}
for label in np.unique(y_train_binned):
    idx = np.where(y_train_binned == label)
    plt.scatter(X_lda[idx, 0], X_lda[idx, 1], label=label, alpha=0.6, color=colors[label])

plt.xlabel('LDA Component 1')
plt.ylabel('LDA Component 2')
plt.title('LDA Projection (log S - Binned Categories)')
plt.legend()
plt.tight_layout()
plt.savefig("lda_projection_logS.png")
plt.show()

import numpy as np
import pandas as pd

# Get descriptor names from your feature DataFrame
descriptor_names = X.columns.tolist()

# Get the LDA loadings (scalings)
lda_components = lda.scalings_[:, :2]  # Shape: [n_features, n_components]

# Create a DataFrame for better readability
lda_df = pd.DataFrame(lda_components, index=descriptor_names, columns=['LDA1', 'LDA2'])

# Calculate absolute contributions for sorting
lda_df['LDA1_abs'] = lda_df['LDA1'].abs()
lda_df['LDA2_abs'] = lda_df['LDA2'].abs()

# Get top 10 descriptors for each component
top_lda1 = lda_df.sort_values('LDA1_abs', ascending=False).head(20)
top_lda2 = lda_df.sort_values('LDA2_abs', ascending=False).head(20)

print("Top 20 contributing descriptors to LDA Component 1:")
print(top_lda1[['LDA1']])

print("\nTop 20 contributing descriptors to LDA Component 2:")
print(top_lda2[['LDA2']])
"""


#top 10 category wise: pca
"""
# === Part 1: Data Preprocessing ===
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors

# Step 1: Load the data
file_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'
data = pd.read_csv(file_path)

# Step 2: Extract the SMILES column and create a list of SMILES strings
smiles_list = data['smiles'].tolist()

# Step 3: Generate a list of all available descriptor names
descriptor_names = [name for name, func in Descriptors._descList]

# Step 4: Calculate descriptors for each molecule
descriptor_data = []
for smiles in smiles_list:
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        descriptor_values = {name: func(mol) for name, func in Descriptors._descList}
        descriptor_data.append(descriptor_values)
    else:
        descriptor_data.append({name: None for name in descriptor_names})  # Handle invalid molecules

# Step 5: Create descriptor DataFrame
descriptor_df = pd.DataFrame(descriptor_data, columns=descriptor_names)

# Step 6: Define relevant descriptors
relevant_descriptors = [
'NumAliphaticHeterocycles','NumAliphaticRings',	'NumAromaticCarbocycles', 'NumAromaticHeterocycles','NumAromaticRings',	'NumHeteroatoms',	'NumRotatableBonds', 'NumSaturatedHeterocycles', 'NumSaturatedRings', 
'BalabanJ', 'BertzCT', 'Chi0', 'Chi1', 'Chi2n', 'Chi3n', 'Chi4n', 'Chi0v', 'Chi1v', 'Chi2v', 'Chi3v', 'Chi4v'
]

# Step 7: Filter to relevant descriptors
filtered_descriptor_df = descriptor_df[relevant_descriptors]

# Step 8: Combine with original data
final_data = pd.concat([data, filtered_descriptor_df], axis=1)

# Step 9: Keep only numeric values and drop rows with any NaNs in descriptors or target
X = final_data[relevant_descriptors].apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(final_data['log S'], errors='coerce')

X = X.dropna()
y = y.loc[X.index]  # align y

# Step 10: Final train-test split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# === Part 11: Apply PCA ===
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Step 11.1: Scale the features before applying PCA
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Step 11.2: Apply PCA (you can adjust n_components as needed, e.g., 0.95 for 95% variance)
pca = PCA(n_components=0.95)  # Retains 95% of variance
X_train_pca = pca.fit_transform(X_train_scaled)
X_test_pca = pca.transform(X_test_scaled)

# Step 11.3: Check how many components were retained
print(f"PCA reduced feature dimensions from {X_train.shape[1]} to {X_train_pca.shape[1]}")

import matplotlib.pyplot as plt
import numpy as np

# Plot cumulative explained variance
plt.figure(figsize=(8, 5))
plt.plot(np.cumsum(pca.explained_variance_ratio_), marker='o')
plt.xlabel('Number of Principal Components')
plt.ylabel('Cumulative Explained Variance')
plt.title('PCA - Explained Variance')
plt.grid(True)
plt.tight_layout()
plt.savefig("pca_molecular_shape.png")
plt.show()

# Get the loadings (influence of each descriptor on the principal components)
pca_components = pca.components_[0]  # first principal component
feature_influence = pd.Series(np.abs(pca_components), index=relevant_descriptors)

# Top 10 most influential descriptors
top10 = feature_influence.sort_values(ascending=False).head(10)

# Plot
plt.figure(figsize=(8, 5))
top10.plot(kind='barh', color='skyblue')
plt.gca().invert_yaxis()
plt.xlabel('Absolute Loading on PC1')
plt.title('Top 10 Most Influential Descriptors (PC1)')
plt.tight_layout()
plt.show()

print("Top 10 Most Influential Descriptors:\n", top10)
"""




#feature selection for category wise
"""
# === Part 1: Data Preprocessing ===
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors

# Step 1: Load the data
file_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'
data = pd.read_csv(file_path)

# Step 2: Extract the SMILES column and create a list of SMILES strings
smiles_list = data['smiles'].tolist()

# Step 3: Generate a list of all available descriptor names
descriptor_names = [name for name, func in Descriptors._descList]

# Step 4: Calculate descriptors for each molecule
descriptor_data = []
for smiles in smiles_list:
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        descriptor_values = {name: func(mol) for name, func in Descriptors._descList}
        descriptor_data.append(descriptor_values)
    else:
        descriptor_data.append({name: None for name in descriptor_names})  # Handle invalid molecules

# Step 5: Create descriptor DataFrame
descriptor_df = pd.DataFrame(descriptor_data, columns=descriptor_names)

# Step 6: Define relevant descriptors
relevant_descriptors = [
'fr_Al_COO', 'fr_Al_OH', 'fr_Al_OH_noTert', 'fr_ArN', 'fr_Ar_COO', 'fr_Ar_N', 'fr_Ar_NH', 'fr_Ar_OH', 'fr_COO', 'fr_COO2',
'fr_C_O', 'fr_C_O_noCOO', 'fr_C_S', 'fr_HOCCN', 'fr_Imine', 'fr_NH0', 'fr_NH1', 'fr_NH2', 'fr_N_O', 'fr_Ndealkylation1',
'fr_Ndealkylation2', 'fr_Nhpyrrole', 'fr_SH', 'fr_aldehyde', 'fr_alkyl_carbamate', 'fr_alkyl_halide', 'fr_allylic_oxid',
'fr_amide', 'fr_amidine', 'fr_aniline', 'fr_aryl_methyl', 'fr_azide', 'fr_azo', 'fr_barbitur', 'fr_benzene', 'fr_benzodiazepine',
'fr_bicyclic', 'fr_diazo', 'fr_dihydropyridine', 'fr_epoxide', 'fr_ester', 'fr_ether', 'fr_furan', 'fr_guanido', 'fr_halogen',
'fr_hdrzine', 'fr_hdrzone', 'fr_imidazole', 'fr_imide', 'fr_isocyan', 'fr_isothiocyan', 'fr_ketone', 'fr_ketone_Topliss',
'fr_lactam', 'fr_lactone', 'fr_methoxy', 'fr_morpholine', 'fr_nitrile', 'fr_nitro', 'fr_nitro_arom', 'fr_nitro_arom_nonortho',
'fr_nitroso', 'fr_oxazole', 'fr_oxime', 'fr_para_hydroxylation', 'fr_phenol', 'fr_phenol_noOrthoHbond', 'fr_phos_acid',
'fr_phos_ester', 'fr_piperdine', 'fr_piperzine', 'fr_priamide', 'fr_prisulfonamd', 'fr_pyridine', 'fr_quatN', 'fr_sulfide',
'fr_sulfonamd', 'fr_sulfone', 'fr_term_acetylene', 'fr_tetrazole', 'fr_thiazole', 'fr_thiocyan', 'fr_thiophene', 'fr_unbrch_alkane',
'fr_urea', 'Ipc', 'Kappa1', 'Kappa2', 'Kappa3', 'MaxPartialCharge', 'MinPartialCharge', 'NumRadicalElectrons',
 'RingCount'
]

# Step 7: Filter to relevant descriptors
filtered_descriptor_df = descriptor_df[relevant_descriptors]

# Step 8: Combine with original data
final_data = pd.concat([data, filtered_descriptor_df], axis=1)

# Step 9: Keep only numeric values and drop rows with any NaNs in descriptors or target
X = final_data[relevant_descriptors].apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(final_data['log S'], errors='coerce')

X = X.dropna()
y = y.loc[X.index]  # align y

# Step 10: Final train-test split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


from sklearn.feature_selection import SelectKBest, f_regression
import matplotlib.pyplot as plt
import pandas as pd

# Apply univariate linear regression test
selector = SelectKBest(score_func=f_regression, k=10)
X_selected = selector.fit_transform(X, y)

# Get scores and feature names
scores = selector.scores_
mask = selector.get_support()
selected_features = X.columns[mask]
selected_scores = scores[mask]

# Combine into a DataFrame and sort
feature_scores_df = pd.DataFrame({
    'Feature': selected_features,
    'Score': selected_scores
}).sort_values(by='Score', ascending=False)

# Print nicely
print("Top 10 selected features (Univariate):")
print(feature_scores_df)

# Plot
plt.figure(figsize=(8, 5))
plt.barh(feature_scores_df['Feature'], feature_scores_df['Score'], color='teal')
plt.gca().invert_yaxis()
plt.xlabel("F-score")
plt.title("Top 10 Features by Univariate Linear Regression")
plt.tight_layout()
plt.savefig("lda_miscellaneous.png")
plt.show()
"""



#feature selection category wise(catboost)
"""
# === Part 1: Data Preprocessing ===
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors

# Step 1: Load the data
file_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'
data = pd.read_csv(file_path)

# Step 2: Extract the SMILES column and create a list of SMILES strings
smiles_list = data['smiles'].tolist()

# Step 3: Generate a list of all available descriptor names
descriptor_names = [name for name, func in Descriptors._descList]

# Step 4: Calculate descriptors for each molecule
descriptor_data = []
for smiles in smiles_list:
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        descriptor_values = {name: func(mol) for name, func in Descriptors._descList}
        descriptor_data.append(descriptor_values)
    else:
        descriptor_data.append({name: None for name in descriptor_names})  # Handle invalid molecules

# Step 5: Create descriptor DataFrame
descriptor_df = pd.DataFrame(descriptor_data, columns=descriptor_names)

# Step 6: Define relevant descriptors
relevant_descriptors = [
'MolWt','HeavyAtomMolWt','ExactMolWt','LabuteASA','PEOE_VSA1','PEOE_VSA10','PEOE_VSA11','PEOE_VSA12',
'PEOE_VSA13','PEOE_VSA14','PEOE_VSA2','PEOE_VSA3','PEOE_VSA4','PEOE_VSA5','PEOE_VSA6','PEOE_VSA7','PEOE_VSA8',
'PEOE_VSA9','SMR_VSA1','SMR_VSA10','SMR_VSA2','SMR_VSA3','SMR_VSA4','SMR_VSA5','SMR_VSA6','SMR_VSA7',
'SMR_VSA8','SMR_VSA9','SlogP_VSA1','SlogP_VSA10','SlogP_VSA11','SlogP_VSA12','SlogP_VSA2','SlogP_VSA3','SlogP_VSA4','SlogP_VSA5',
'SlogP_VSA6','SlogP_VSA7','SlogP_VSA8','SlogP_VSA9','TPSA','HeavyAtomCount',
'FpDensityMorgan1', 'FpDensityMorgan2', 'FpDensityMorgan3', 'FractionCSP3', 'MolMR', 'NHOHCount',
 'NOCount', 'NumHAcceptors', 'NumHDonors', 'NumValenceElectrons'
]

# Step 7: Filter to relevant descriptors
filtered_descriptor_df = descriptor_df[relevant_descriptors]

# Step 8: Combine with original data
final_data = pd.concat([data, filtered_descriptor_df], axis=1)

# Step 9: Keep only numeric values and drop rows with any NaNs in descriptors or target
X = final_data[relevant_descriptors].apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(final_data['log S'], errors='coerce')

X = X.dropna()
y = y.loc[X.index]  # align y

# Step 10: Final train-test split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


from catboost import CatBoostRegressor, Pool
import pandas as pd
import matplotlib.pyplot as plt

# Define CatBoost model
model = CatBoostRegressor(verbose=0, random_state=42)

# Fit model on entire dataset
model.fit(X, y)

# Get feature importances
feature_importance = model.get_feature_importance(Pool(X, y))
feature_importance_series = pd.Series(feature_importance, index=X.columns).sort_values(ascending=False)

# Convert to DataFrame for better display
top_k = 10
top_features_df = feature_importance_series.head(top_k).reset_index()
top_features_df.columns = ['Feature', 'Importance']

# Print the top 10 features and their importance scores
print("Top 10 selected features (CatBoost):")
print(top_features_df)

# Plot
plt.figure(figsize=(8, 5))
plt.barh(top_features_df['Feature'], top_features_df['Importance'], color='purple')
plt.gca().invert_yaxis()
plt.xlabel("Importance Score")
plt.title("Top 10 Most Influential Features (CatBoost)")
plt.tight_layout()
plt.savefig("feature_selection_catboost_molecular_shape.png")
plt.show()
"""

