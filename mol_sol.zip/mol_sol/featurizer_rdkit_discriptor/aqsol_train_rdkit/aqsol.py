

# training and testing data: aqsol
"""
import pandas as pd
import deepchem as dc
from rdkit import Chem

# Load your dataset (replace with the correct path)
data_path = '/content/drive/MyDrive/mol_sol/datasets/aqsol_cure1.csv'# Update with your file path
data = pd.read_csv(data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings
smiles_list = data['smiles'].tolist()  # Replace 'molecules' with your column name if different

# Convert SMILES strings to RDKit Molecule objects
molecules = [Chem.MolFromSmiles(smiles) for smiles in smiles_list]

# Filter out invalid molecules
valid_molecules = [mol for mol in molecules if mol is not None]

# Apply the featurizer to the valid molecules
features = featurizer.featurize(valid_molecules)

# Extract the descriptor names from the featurizer
descriptor_names = featurizer.featurize([Chem.MolFromSmiles('CC')])[0].shape[0]  # Adjusting to fetch descriptor names correctly

# Convert features to a DataFrame
features_df = pd.DataFrame(features, columns=[f"desc_{i}" for i in range(descriptor_names)])

# Combine features with the target variable
final_data = pd.concat([features_df, data['log S'].iloc[:len(features_df)]], axis=1)  # Replace 'solubility' if your column name differs

# Save the featurized data (optional)
final_data.to_csv('featurized_data.csv', index=False)
print(final_data.head())

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor, BaggingRegressor, AdaBoostRegressor, HistGradientBoostingRegressor, StackingRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Load the featurized data
featurized_data = pd.read_csv('featurized_data.csv')

# Drop rows with missing values
featurized_data = featurized_data.dropna()

# Split features and target
X = featurized_data.drop('log S', axis=1)  # Replace 'log S' with your actual target column name
y = featurized_data['log S']

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Define initial models to evaluate
initial_models = {
    'Linear Regression': LinearRegression(),
    'Ridge Regression': Ridge(),
    'Lasso Regression': Lasso(),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, random_state=42)
}

# Train and evaluate initial models
print("\nEvaluating Initial Models:")
for name, model in initial_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Define additional models
additional_models = {
    'Support Vector Regressor': SVR(),
    'XGBoost Regressor': XGBRegressor(),
    'LightGBM Regressor': LGBMRegressor(),
    'CatBoost Regressor': CatBoostRegressor(verbose=0),
    'Extra Trees Regressor': ExtraTreesRegressor(),
    'KNN Regressor': KNeighborsRegressor(),
    'ElasticNet': ElasticNet()
}

# Evaluate additional models
print("\nEvaluating Additional Models:")
for model_name, model in additional_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Further models for evaluation
further_models = {
    'Bagging Regressor': BaggingRegressor(),
    'AdaBoost Regressor': AdaBoostRegressor(),
    'HistGradientBoosting Regressor': HistGradientBoostingRegressor()
}

# Evaluate further models
print("\nEvaluating Further Models:")
for model_name, model in further_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")
  """








#Training data: aqsol, Testing data: anti_cancer 


import numpy as np
import pandas as pd
import deepchem as dc
from rdkit import Chem
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor, BaggingRegressor, AdaBoostRegressor, HistGradientBoostingRegressor, StackingRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Paths to your datasets
train_data_path = '/content/drive/MyDrive/mol_sol/datasets/aqsol_cure1.csv'
test_data_path = '/content/drive/MyDrive/mol_sol/datasets/anti_cancer_data.csv'

# Load training and testing datasets
train_data = pd.read_csv(train_data_path)
test_data = pd.read_csv(test_data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings for training and testing datasets
train_smiles_list = train_data['smiles'].tolist()
test_smiles_list = test_data['smiles'].tolist()

# Convert SMILES strings to RDKit Molecule objects
train_molecules = [Chem.MolFromSmiles(smiles) for smiles in train_smiles_list]
test_molecules = [Chem.MolFromSmiles(smiles) for smiles in test_smiles_list]

# Filter out invalid molecules
valid_train_molecules = [mol for mol in train_molecules if mol is not None]
valid_test_molecules = [mol for mol in test_molecules if mol is not None]

# Apply the featurizer to valid molecules
train_features = featurizer.featurize(valid_train_molecules)
test_features = featurizer.featurize(valid_test_molecules)

# Extract the descriptor names from the featurizer
descriptor_count = train_features[0].shape[0]

# Convert features to DataFrame for both training and testing sets
train_features_df = pd.DataFrame(train_features, columns=[f"desc_{i}" for i in range(descriptor_count)])
test_features_df = pd.DataFrame(test_features, columns=[f"desc_{i}" for i in range(descriptor_count)])

# Combine features with the target variable
train_final_data = pd.concat([train_features_df, train_data['log S'].iloc[:len(train_features_df)]], axis=1)
test_final_data = pd.concat([test_features_df, test_data['log S'].iloc[:len(test_features_df)]], axis=1)

# Drop rows with missing values in both datasets
train_final_data = train_final_data.dropna()
test_final_data = test_final_data.dropna()

# Split features and target
X_train = train_final_data.drop('log S', axis=1)
y_train = train_final_data['log S']
X_test = test_final_data.drop('log S', axis=1)
y_test = test_final_data['log S']

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Define initial models to evaluate
initial_models = {
    'Linear Regression': LinearRegression(),
    'Ridge Regression': Ridge(),
    'Lasso Regression': Lasso(),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, random_state=42)
}

# Train and evaluate initial models
print("\nEvaluating Initial Models on Test Set:")
for name, model in initial_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Define additional models
additional_models = {
    'Support Vector Regressor': SVR(),
    'XGBoost Regressor': XGBRegressor(),
    'LightGBM Regressor': LGBMRegressor(),
    'CatBoost Regressor': CatBoostRegressor(verbose=0),
    'Extra Trees Regressor': ExtraTreesRegressor(),
    'KNN Regressor': KNeighborsRegressor(),
    'ElasticNet': ElasticNet()
}

# Evaluate additional models
print("\nEvaluating Additional Models on Test Set:")
for model_name, model in additional_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Further models for evaluation
further_models = {
    'Bagging Regressor': BaggingRegressor(),
    'AdaBoost Regressor': AdaBoostRegressor(),
    'HistGradientBoosting Regressor': HistGradientBoostingRegressor()
}

# Evaluate further models
print("\nEvaluating Further Models on Test Set:")
for model_name, model in further_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")





#Training data: aqsol, Testing data: esol



"""
import numpy as np
import pandas as pd
import deepchem as dc
from rdkit import Chem
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor, BaggingRegressor, AdaBoostRegressor, HistGradientBoostingRegressor, StackingRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Paths to your datasets
train_data_path = '/content/drive/MyDrive/mol_sol/datasets/aqsol_cure1.csv'
test_data_path = '/content/drive/MyDrive/mol_sol/datasets/esol_cure1.csv'

# Load training and testing datasets
train_data = pd.read_csv(train_data_path)
test_data = pd.read_csv(test_data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings for training and testing datasets
train_smiles_list = train_data['smiles'].tolist()
test_smiles_list = test_data['smiles'].tolist()

# Convert SMILES strings to RDKit Molecule objects
train_molecules = [Chem.MolFromSmiles(smiles) for smiles in train_smiles_list]
test_molecules = [Chem.MolFromSmiles(smiles) for smiles in test_smiles_list]

# Filter out invalid molecules
valid_train_molecules = [mol for mol in train_molecules if mol is not None]
valid_test_molecules = [mol for mol in test_molecules if mol is not None]

# Apply the featurizer to valid molecules
train_features = featurizer.featurize(valid_train_molecules)
test_features = featurizer.featurize(valid_test_molecules)

# Extract the descriptor names from the featurizer
descriptor_count = train_features[0].shape[0]

# Convert features to DataFrame for both training and testing sets
train_features_df = pd.DataFrame(train_features, columns=[f"desc_{i}" for i in range(descriptor_count)])
test_features_df = pd.DataFrame(test_features, columns=[f"desc_{i}" for i in range(descriptor_count)])

# Combine features with the target variable
train_final_data = pd.concat([train_features_df, train_data['log S'].iloc[:len(train_features_df)]], axis=1)
test_final_data = pd.concat([test_features_df, test_data['log S'].iloc[:len(test_features_df)]], axis=1)

# Drop rows with missing values in both datasets
train_final_data = train_final_data.dropna()
test_final_data = test_final_data.dropna()

# Split features and target
X_train = train_final_data.drop('log S', axis=1)
y_train = train_final_data['log S']
X_test = test_final_data.drop('log S', axis=1)
y_test = test_final_data['log S']

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Define initial models to evaluate
initial_models = {
    'Linear Regression': LinearRegression(),
    'Ridge Regression': Ridge(),
    'Lasso Regression': Lasso(),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, random_state=42)
}

# Train and evaluate initial models
print("\nEvaluating Initial Models on Test Set:")
for name, model in initial_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Define additional models
additional_models = {
    'Support Vector Regressor': SVR(),
    'XGBoost Regressor': XGBRegressor(),
    'LightGBM Regressor': LGBMRegressor(),
    'CatBoost Regressor': CatBoostRegressor(verbose=0),
    'Extra Trees Regressor': ExtraTreesRegressor(),
    'KNN Regressor': KNeighborsRegressor(),
    'ElasticNet': ElasticNet()
}

# Evaluate additional models
print("\nEvaluating Additional Models on Test Set:")
for model_name, model in additional_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Further models for evaluation
further_models = {
    'Bagging Regressor': BaggingRegressor(),
    'AdaBoost Regressor': AdaBoostRegressor(),
    'HistGradientBoosting Regressor': HistGradientBoostingRegressor()
}

# Evaluate further models
print("\nEvaluating Further Models on Test Set:")
for model_name, model in further_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")
"""




#Training data: aqsol, Testing data: aqua

"""
import numpy as np
import pandas as pd
import deepchem as dc
from rdkit import Chem
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor, BaggingRegressor, AdaBoostRegressor, HistGradientBoostingRegressor, StackingRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Paths to your datasets
train_data_path = '/content/drive/MyDrive/mol_sol/datasets/aqsol_cure1.csv'
test_data_path = '/content/drive/MyDrive/mol_sol/datasets/aqua_cure1.csv'

# Load training and testing datasets
train_data = pd.read_csv(train_data_path)
test_data = pd.read_csv(test_data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings for training and testing datasets
train_smiles_list = train_data['smiles'].tolist()
test_smiles_list = test_data['smiles'].tolist()

# Convert SMILES strings to RDKit Molecule objects
train_molecules = [Chem.MolFromSmiles(smiles) for smiles in train_smiles_list]
test_molecules = [Chem.MolFromSmiles(smiles) for smiles in test_smiles_list]

# Filter out invalid molecules
valid_train_molecules = [mol for mol in train_molecules if mol is not None]
valid_test_molecules = [mol for mol in test_molecules if mol is not None]

# Apply the featurizer to valid molecules
train_features = featurizer.featurize(valid_train_molecules)
test_features = featurizer.featurize(valid_test_molecules)

# Extract the descriptor names from the featurizer
descriptor_count = train_features[0].shape[0]

# Convert features to DataFrame for both training and testing sets
train_features_df = pd.DataFrame(train_features, columns=[f"desc_{i}" for i in range(descriptor_count)])
test_features_df = pd.DataFrame(test_features, columns=[f"desc_{i}" for i in range(descriptor_count)])

# Combine features with the target variable
train_final_data = pd.concat([train_features_df, train_data['log S'].iloc[:len(train_features_df)]], axis=1)
test_final_data = pd.concat([test_features_df, test_data['log S'].iloc[:len(test_features_df)]], axis=1)

# Drop rows with missing values in both datasets
train_final_data = train_final_data.dropna()
test_final_data = test_final_data.dropna()

# Split features and target
X_train = train_final_data.drop('log S', axis=1)
y_train = train_final_data['log S']
X_test = test_final_data.drop('log S', axis=1)
y_test = test_final_data['log S']

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Define initial models to evaluate
initial_models = {
    'Linear Regression': LinearRegression(),
    'Ridge Regression': Ridge(),
    'Lasso Regression': Lasso(),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, random_state=42)
}

# Train and evaluate initial models
print("\nEvaluating Initial Models on Test Set:")
for name, model in initial_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Define additional models
additional_models = {
    'Support Vector Regressor': SVR(),
    'XGBoost Regressor': XGBRegressor(),
    'LightGBM Regressor': LGBMRegressor(),
    'CatBoost Regressor': CatBoostRegressor(verbose=0),
    'Extra Trees Regressor': ExtraTreesRegressor(),
    'KNN Regressor': KNeighborsRegressor(),
    'ElasticNet': ElasticNet()
}

# Evaluate additional models
print("\nEvaluating Additional Models on Test Set:")
for model_name, model in additional_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Further models for evaluation
further_models = {
    'Bagging Regressor': BaggingRegressor(),
    'AdaBoost Regressor': AdaBoostRegressor(),
    'HistGradientBoosting Regressor': HistGradientBoostingRegressor()
}

# Evaluate further models
print("\nEvaluating Further Models on Test Set:")
for model_name, model in further_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")
"""



#training data:aqsol, testing data:phys


"""
import numpy as np
import pandas as pd
import deepchem as dc
from rdkit import Chem
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor, BaggingRegressor, AdaBoostRegressor, HistGradientBoostingRegressor, StackingRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Paths to your datasets
train_data_path = '/content/drive/MyDrive/mol_sol/datasets/aqsol_cure1.csv'
test_data_path = '/content/drive/MyDrive/mol_sol/datasets/phys_cure1.csv'

# Load training and testing datasets
train_data = pd.read_csv(train_data_path)
test_data = pd.read_csv(test_data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings for training and testing datasets
train_smiles_list = train_data['smiles'].tolist()
test_smiles_list = test_data['smiles'].tolist()

# Convert SMILES strings to RDKit Molecule objects
train_molecules = [Chem.MolFromSmiles(smiles) for smiles in train_smiles_list]
test_molecules = [Chem.MolFromSmiles(smiles) for smiles in test_smiles_list]

# Filter out invalid molecules
valid_train_molecules = [mol for mol in train_molecules if mol is not None]
valid_test_molecules = [mol for mol in test_molecules if mol is not None]

# Apply the featurizer to valid molecules
train_features = featurizer.featurize(valid_train_molecules)
test_features = featurizer.featurize(valid_test_molecules)

# Extract the descriptor names from the featurizer
descriptor_count = train_features[0].shape[0]

# Convert features to DataFrame for both training and testing sets
train_features_df = pd.DataFrame(train_features, columns=[f"desc_{i}" for i in range(descriptor_count)])
test_features_df = pd.DataFrame(test_features, columns=[f"desc_{i}" for i in range(descriptor_count)])

# Combine features with the target variable
train_final_data = pd.concat([train_features_df, train_data['log S'].iloc[:len(train_features_df)]], axis=1)
test_final_data = pd.concat([test_features_df, test_data['log S'].iloc[:len(test_features_df)]], axis=1)

# Drop rows with missing values in both datasets
train_final_data = train_final_data.dropna()
test_final_data = test_final_data.dropna()

# Split features and target
X_train = train_final_data.drop('log S', axis=1)
y_train = train_final_data['log S']
X_test = test_final_data.drop('log S', axis=1)
y_test = test_final_data['log S']

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Define initial models to evaluate
initial_models = {
    'Linear Regression': LinearRegression(),
    'Ridge Regression': Ridge(),
    'Lasso Regression': Lasso(),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, random_state=42)
}

# Train and evaluate initial models
print("\nEvaluating Initial Models on Test Set:")
for name, model in initial_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Define additional models
additional_models = {
    'Support Vector Regressor': SVR(),
    'XGBoost Regressor': XGBRegressor(),
    'LightGBM Regressor': LGBMRegressor(),
    'CatBoost Regressor': CatBoostRegressor(verbose=0),
    'Extra Trees Regressor': ExtraTreesRegressor(),
    'KNN Regressor': KNeighborsRegressor(),
    'ElasticNet': ElasticNet()
}

# Evaluate additional models
print("\nEvaluating Additional Models on Test Set:")
for model_name, model in additional_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Further models for evaluation
further_models = {
    'Bagging Regressor': BaggingRegressor(),
    'AdaBoost Regressor': AdaBoostRegressor(),
    'HistGradientBoosting Regressor': HistGradientBoostingRegressor()
}

# Evaluate further models
print("\nEvaluating Further Models on Test Set:")
for model_name, model in further_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")
"""


#training data:aqsol , testing data: ochem
"""
import numpy as np
import pandas as pd
import deepchem as dc
from rdkit import Chem
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor, BaggingRegressor, AdaBoostRegressor, HistGradientBoostingRegressor, StackingRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Paths to your datasets
train_data_path = '/content/drive/MyDrive/mol_sol/datasets/aqsol_cure1.csv'
test_data_path = '/content/drive/MyDrive/mol_sol/datasets/ochem_cure1.csv'

# Load training and testing datasets
train_data = pd.read_csv(train_data_path)
test_data = pd.read_csv(test_data_path)

# Initialize RDKitDescriptors featurizer
featurizer = dc.feat.RDKitDescriptors()

# Extract SMILES strings for training and testing datasets
train_smiles_list = train_data['smiles'].tolist()
test_smiles_list = test_data['smiles'].tolist()

# Convert SMILES strings to RDKit Molecule objects
train_molecules = [Chem.MolFromSmiles(smiles) for smiles in train_smiles_list]
test_molecules = [Chem.MolFromSmiles(smiles) for smiles in test_smiles_list]

# Filter out invalid molecules
valid_train_molecules = [mol for mol in train_molecules if mol is not None]
valid_test_molecules = [mol for mol in test_molecules if mol is not None]

# Apply the featurizer to valid molecules
train_features = featurizer.featurize(valid_train_molecules)
test_features = featurizer.featurize(valid_test_molecules)

# Extract the descriptor names from the featurizer
descriptor_count = train_features[0].shape[0]

# Convert features to DataFrame for both training and testing sets
train_features_df = pd.DataFrame(train_features, columns=[f"desc_{i}" for i in range(descriptor_count)])
test_features_df = pd.DataFrame(test_features, columns=[f"desc_{i}" for i in range(descriptor_count)])

# Combine features with the target variable
train_final_data = pd.concat([train_features_df, train_data['log S'].iloc[:len(train_features_df)]], axis=1)
test_final_data = pd.concat([test_features_df, test_data['log S'].iloc[:len(test_features_df)]], axis=1)

# Drop rows with missing values in both datasets
train_final_data = train_final_data.dropna()
test_final_data = test_final_data.dropna()

# Split features and target
X_train = train_final_data.drop('log S', axis=1)
y_train = train_final_data['log S']
X_test = test_final_data.drop('log S', axis=1)
y_test = test_final_data['log S']

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Define initial models to evaluate
initial_models = {
    'Linear Regression': LinearRegression(),
    'Ridge Regression': Ridge(),
    'Lasso Regression': Lasso(),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, random_state=42)
}

# Train and evaluate initial models
print("\nEvaluating Initial Models on Test Set:")
for name, model in initial_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Define additional models
additional_models = {
    'Support Vector Regressor': SVR(),
    'XGBoost Regressor': XGBRegressor(),
    'LightGBM Regressor': LGBMRegressor(),
    'CatBoost Regressor': CatBoostRegressor(verbose=0),
    'Extra Trees Regressor': ExtraTreesRegressor(),
    'KNN Regressor': KNeighborsRegressor(),
    'ElasticNet': ElasticNet()
}

# Evaluate additional models
print("\nEvaluating Additional Models on Test Set:")
for model_name, model in additional_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")

# Further models for evaluation
further_models = {
    'Bagging Regressor': BaggingRegressor(),
    'AdaBoost Regressor': AdaBoostRegressor(),
    'HistGradientBoosting Regressor': HistGradientBoostingRegressor()
}

# Evaluate further models
print("\nEvaluating Further Models on Test Set:")
for model_name, model in further_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    print(f"{model_name} - MSE: {mse:.4f}, RMSE: {rmse:.4f}, R2 Score: {r2:.4f}")
    """